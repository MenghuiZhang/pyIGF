# pylint: skip-file
# from pyrevit import HOST_APP, EXEC_PARAMS

# args = EXEC_PARAMS.event_args

# import hooks_logger as hl
# hl.log_hook(__file__,
#     {
#         "cancellable?": str(args.Cancellable),
#     }
# )