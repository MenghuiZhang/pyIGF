# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import *
import rpw
import time
import clr
import System
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import *
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel

start = time.time()

__title__ = "8.21 mit Bearbeitsungsbereiche nur Rohr-Bauteile"
__doc__ = """BIM-ID aus excel in Modell schreiben(Systeme, Leitung, Formteile)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()
bimid_config = script.get_config()

from pyIGF_logInfo import getlog
getlog(__title__)

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# Bearbeitungsbereich
worksets = FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset)
Workset_dict = {}
for el in worksets:
    Workset_dict[el.Name] = el.Id.ToString()

# Exceldaten
class Exceldaten(object):
    def __init__(self):
        self.Systemname = ''
        self.GK = ''
        self.KG = ''
        self.KN01 = ''
        self.KN02 = ''
        self.BIMID = ''
        self.Workset = ''


    @property
    def Systemname(self):
        return self._Systemname
    @Systemname.setter
    def Systemname(self, value):
        self._Systemname = value
    @property
    def GK(self):
        return self._GK
    @GK.setter
    def GK(self, value):
        self._GK = value
    @property
    def KG(self):
        return self._KG
    @KG.setter
    def KG(self, value):
        self._KG = value
    @property
    def KN01(self):
        return self._KN01
    @KN01.setter
    def KN01(self, value):
        self._KN01 = value
    @property
    def KN02(self):
        return self._KN02
    @KN02.setter
    def KN02(self, value):
        self._KN02 = value#
    @property
    def BIMID(self):
        return self._BIMID
    @BIMID.setter
    def BIMID(self, value):
        self._BIMID = value
    @property
    def Workset(self):
        return self._Workset
    @Workset.setter
    def Workset(self, value):
        self._Workset = value

Liste_Luft = ObservableCollection[Exceldaten]()
Liste_Rohr = ObservableCollection[Exceldaten]()
Liste_Elektro = ObservableCollection[Exceldaten]()
Liste_Alle = ObservableCollection[Exceldaten]()


def datenlesen(filepath):
    ex = Excel.ApplicationClass()
    _nova_Nr_Id = {}
    book = ex.Workbooks.Open(filepath)
    for sheet in book.Worksheets:
        name = sheet.Name
        rows = sheet.UsedRange.Rows.Count
        for row in range(2,rows+1):
            tempclass = Exceldaten()
            sysname = sheet.Cells[row, 1].Value2
            GK = sheet.Cells[row, 2].Value2
            KG = str(int(sheet.Cells[row, 3].Value2))
            KN01 = str(int(sheet.Cells[row, 4].Value2))
            if len(KN01) == 1:
                KN01 = '0' + KN01
            KN02 = str(int(sheet.Cells[row, 5].Value2))
            if len(KN02) == 1:
                KN02 = '0' + KN02
            workset = sheet.Cells[row, 7].Value2
            bimid = GK + '_' + KG + '_' + KN01 + ' ' + KN02
            tempclass.Systemname = sysname
            tempclass.GK = GK
            tempclass.KG = KG
            tempclass.KN01 = KN01
            tempclass.KN02 = KN02
            tempclass.BIMID = bimid
            tempclass.Workset = workset
            if name == 'Rohr':
                Liste_Rohr.Add(tempclass)
                Liste_Alle.Add(tempclass)
            elif name == 'Luft':
                Liste_Luft.Add(tempclass)
                Liste_Alle.Add(tempclass)
            elif name == 'Elektro':
                Liste_Elektro.Add(tempclass)
                Liste_Alle.Add(tempclass)
    book.Save()
    book.Close()
    ex.Quit()
    generation = System.GC.GetGeneration(ex)
    ex = None

try:
    Adresse = bimid_config.bimid
    datenausexcel = {}
    try:
        datenlesen(Adresse)
    except Exception as e:
        logger.error(e)
except:
    pass


# ExcelBimId Pläne
class ExcelBimId(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_Elektro,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_Rohr = liste_Rohr
        self.liste_Elektro = liste_Elektro
        self.liste_All = liste_All
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[Exceldaten]()
        self.altdatagrid = None
        self.read_config()
        self.Tempsource = None

        try:
            self.dataGrid.ItemsSource = self.liste_Rohr
            self.altdatagrid = self.liste_Rohr
            self.backAll()
            self.click(self.rohr)
        except Exception as e:
            logger.error(e)

        self.systemsuche.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.excel_changed

    def read_config(self):
        try:
            self.Adresse.Text = str(bimid_config.bimid)
        except:
            self.Adresse.Text = bimid_config.bimid = ""

    def write_config(self):
        bimid_config.bimid = self.Adresse.Text.encode('utf-8')
        script.save_config()

# Button Farbe ändern
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic

# Button Farbe zurücksetzen
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.SucheSystemtyp.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.System.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def excel_changed(self, sender, args):
        Liste_Luft.Clear()
        Liste_Rohr.Clear()
        Liste_Elektro.Clear()
        Liste_Alle.Clear()
        try:
            datenlesen(self.Adresse.Text)
        except:
            pass
        self.liste_Luft = Liste_Luft
        self.liste_Rohr = Liste_Rohr
        self.liste_Elektro = Liste_Elektro
        self.liste_All = Liste_Alle
        self.dataGrid.ItemsSource = Liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.backAll()
        self.click(self.rohr)

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "BIM-ID Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName
        self.write_config()

    def backAll(self):
        def back(button):
            button.Background  = Brushes.White
            button.FontWeight = FontWeights.Normal
            button.FontStyle = FontStyles.Normal
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.elek)

    def lueftung(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()

    def rohre(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()

    def elektro(self,sender,args):
        self.backAll()
        self.click(self.elek)
        self.dataGrid.ItemsSource = self.liste_Elektro
        self.altdatagrid = self.liste_Elektro
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        self.Close()

windowExcelBimId = ExcelBimId("Window.xaml",Liste_Luft,Liste_Rohr,Liste_Elektro,Liste_Alle)
windowExcelBimId.ShowDialog()



DictAusExcel = {}
for el in Liste_Alle:
    DictAusExcel[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset
    ]

def DatenSchreiben_Bauteile(ids,Category):
    tranitle = 'Daten schreiben (' + Category + ')'
    title = "{value}/{max_value} Daten in Kategorie " + Category
    step = int(len(ids)/1000) + 1
    t = Transaction(doc,tranitle)
    t.Start()
    n = 1
    with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
        for id in ids:
            if pb.cancelled:
                t.RollBack()
                script.exit()
            pb.update_progress(n, len(ids))
            n += 1
            system = None
            elem = doc.GetElement(id)
            try:
                system = elem.MEPSystem
            except:
                try:
                    conns_temp = elem.MEPModel.ConnectorManager.Connectors
                    connsmitid = [[item.Id.ToString(),item] for item in conns_temp]
                    connsmitid.sort()
                    conns = [item[1] for item in connsmitid]

                    for conn in conns:
                        if conn.IsConnected:
                            system = conn.MEPSystem
                            if system:
                                break
                except:
                    system = None
            if not system:
                continue
            systyp = system.LookupParameter('Typ').AsValueString()
            try:
                daten = DictAusExcel[systyp]
                elem.LookupParameter('IGF_X_Gewerkkürzel_Exemplar').Set(str(daten[0]))
                elem.LookupParameter('IGF_X_KG_Exemplar').Set(int(daten[1]))
                elem.LookupParameter('IGF_X_KN01_Exemplar').Set(int(daten[2]))
                elem.LookupParameter('IGF_X_KN02_Exemplar').Set(int(daten[3]))
                elem.LookupParameter('IGF_X_BIM-ID_Exemplar').Set(str(daten[4]))
                elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[daten[5]]))
            except:
                pass
    t.Commit()


def DatenSchreiben_Systeme(ids,Category):
    tranitle = 'Daten schreiben (' + Category + ')'
    title = "{value}/{max_value} Daten in Kategorie " + Category
    step = int(len(ids)/100) + 1
    t = Transaction(doc,tranitle)
    t.Start()
    n_1 = 1
    with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
        for id in ids:
            if pb.cancelled:
                t.RollBack()
                script.exit()
            pb.update_progress(n_1, len(ids))
            n_1 += 1
            elem = doc.GetElement(id)
            systyp = elem.LookupParameter('Typ').AsValueString()
            elemtyp = doc.GetElement(elem.GetTypeId())
            try:
                daten = DictAusExcel[systyp]
                elemtyp.LookupParameter('IGF_X_Gewerkkürzel').Set(str(daten[0]))
                elemtyp.LookupParameter('IGF_X_Kostengruppe').Set(int(daten[1]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_1').Set(int(daten[2]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_2').Set(int(daten[3]))
                elemtyp.LookupParameter('IGF_X_BIM-ID').Set(str(daten[4]))
            except Exception as e:
                print(e)
    t.Commit()

# Rohr System
rohrsys = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
rohrsysids = rohrsys.ToElementIds()
rohrsys.Dispose()
# Luft System
luftsys = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
luftsysids = luftsys.ToElementIds()
luftsys.Dispose()
# Allgemeines Modell
AllgModel = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_GenericModel).WhereElementIsNotElementType()
AllgModelids = AllgModel.ToElementIds()
AllgModel.Dispose()
# HLS_Bauteil
HLS = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType()
HLSids = HLS.ToElementIds()
HLS.Dispose()
# Rohrformteile
rohrform = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipeFitting).WhereElementIsNotElementType()
rohrformids = rohrform.ToElementIds()
rohrform.Dispose()
# Rohrzubehör
rohrzu = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipeAccessory).WhereElementIsNotElementType()
rohrzuids = rohrzu.ToElementIds()
rohrzu.Dispose()
# Sanitärinstallation
sani = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PlumbingFixtures).WhereElementIsNotElementType()
saniids = sani.ToElementIds()
sani.Dispose()
# Luftkanalformteile
kanalform = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctFitting).WhereElementIsNotElementType()
kanalformids = kanalform.ToElementIds()
kanalform.Dispose()
# Luftkanalzubehör
kanalzu = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctAccessory).WhereElementIsNotElementType()
kanalzuids = kanalzu.ToElementIds()
kanalzu.Dispose()
# Luftdurchlass
auslass = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctTerminal).WhereElementIsNotElementType()
auslassids = auslass.ToElementIds()
auslass.Dispose()
# Flexkanäle
flexkanal = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_FlexDuctCurves).WhereElementIsNotElementType()
flexkanalids = flexkanal.ToElementIds()
flexkanal.Dispose()
# Flexible Rohre
flexrohr = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_FlexPipeCurves).WhereElementIsNotElementType()
flexrohrids = flexrohr.ToElementIds()
flexrohr.Dispose()
# Kanäle
kanal = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctCurves).WhereElementIsNotElementType()
kanalids = kanal.ToElementIds()
kanal.Dispose()
# Rohre
rohr = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipeCurves).WhereElementIsNotElementType()
rohrids = rohr.ToElementIds()
rohr.Dispose()

DatenSchreiben_Systeme(rohrsysids,'Rohr System')
DatenSchreiben_Systeme(luftsysids,'Luftkanal System')
DatenSchreiben_Bauteile(HLSids,'HLS-Bauteile')
DatenSchreiben_Bauteile(rohrzuids,'Rohrzubehör')
DatenSchreiben_Bauteile(AllgModelids,'Allgemeines Modell')
DatenSchreiben_Bauteile(rohrformids,'Rohrformteile')
DatenSchreiben_Bauteile(saniids,'Sanitärinstallation')
# DatenSchreiben_Bauteile(kanalzuids,'Luftkanalzubehör')
# DatenSchreiben_Bauteile(kanalformids,'Luftkanalformteile')
# DatenSchreiben_Bauteile(auslassids,'Luftdurchlass')
# DatenSchreiben_Bauteile(flexkanalids,'Flexkanäle')
DatenSchreiben_Bauteile(flexrohrids,'Flexible Rohre')
# DatenSchreiben_Bauteile(rohrids,'Rohre')
# DatenSchreiben_Bauteile(kanalids,'Kanäle')
