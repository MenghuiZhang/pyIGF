# coding: utf8

import xlrd
from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import Transaction
import rpw
import time
import clr

start = time.time()

__title__ = "HLS_Bauteile"
__doc__ = """Kostengruppe in Modell schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

bauteile_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment) \
    .WhereElementIsNotElementType()
bauteile = bauteile_collector.ToElementIds()


logger.info("{} HLS Bauteile ausgewählt".format(len(bauteile)))

if not bauteile:
    logger.error("Keine HLS Bauteile in aktueller Projekt gefunden")
    script.exit()


# Daten einlesen
def Daten_einlesen(sheet_name):
    path = "R:\\Vorlagen\\_IGF\\Revit_Parameter\\IGF_Kostengruppen.xlsx"

    book = xlrd.open_workbook(path)
    sheet = book.sheet_by_name(sheet_name)
    rows = sheet.nrows
    cols = sheet.ncols
    Col = []
    for row in range(rows):
        Row = []
        for col in range(cols):
            cell = sheet.cell_value(row,col)
            Row.append(cell)
        Col.append(Row)

    Daten = []
    for i in range(1,len(Col)):
        Daten.append(Col[i])

    output.print_table(
        table_data=Daten,
        title="Daten aus Excel",
        columns=Col[0]
    )

    return Daten

# Namen Änderung
def Name_Aendern(para_name):
    Namen = [['Ä','Ae'], ['Ü','Ue'], ['Ö','Oe'], ['ä','ae'], ['ö','oe'],
             ['ü','ue'], ['—','-'],  ['ß','ss'], ]
    name = ''
    for Buchstabe in para_name:
        for Buchstabe_Gruppe in Namen:
            if Buchstabe == Buchstabe_Gruppe[0]:
                Buchstabe = Buchstabe_Gruppe[1]
        name = name + Buchstabe
    return name

# Schächte von Lüftung übernehmen
def Daten_Schreiben(Familie,Familie_Id,KG_Familie):
    with forms.ProgressBar(title='{value}/{max_value} Kostengruppen schreiben',
                           cancellable=True, step=10) as pb:
        n = 0

        t = Transaction(doc, "Kostengruppen schreiben")
        t.Start()

        for Item in Familie:
            if pb.cancelled:
                script.exit()
            n += 1
            pb.update_progress(n, len(Familie_Id))

            Familie_Name = Item.get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString()
            FamilieName = Name_Aendern(str(Familie_Name))
            print(FamilieName)

            for KG in KG_Familie:
                if FamilieName == KG[0] and KG[1]:
                    Item.LookupParameter("IGF_HLS_KG_Familie").Set(int(KG[1]))
        t.Commit()



HLS_BT_Liste = Daten_einlesen('HLS-Bauteile')
if forms.alert('Kostengruppen schreiben?', ok=False, yes=True, no=True):
    Daten_Schreiben(bauteile_collector,bauteile,HLS_BT_Liste)


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
