# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import *
import rpw
import time
import clr
import System
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import *
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Runtime.InteropServices import Marshal

start = time.time()

__title__ = "8.22 mit Bearbeitsungsbereiche nur Sanitär-Bauteile"
__doc__ = """BIM-ID und Bearbeitunsbereich aus excel in Modell schreiben(Sanitär-Bauteile)"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()
bimid_config = script.get_config()

from pyIGF_logInfo import getlog
getlog(__title__)

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# Bearbeitungsbereich
worksets = FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset)
Workset_dict = {}
for el in worksets:
    Workset_dict[el.Name] = el.Id.ToString()

# Exceldaten
class Exceldaten(object):
    def __init__(self):
        self.checked = False
        self.bb = False
        self.Systemname = ''
        self.GK = ''
        self.KG = ''
        self.KN01 = ''
        self.KN02 = ''
        self.BIMID = ''
        self.Workset = ''

    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def Systemname(self):
        return self._Systemname
    @Systemname.setter
    def Systemname(self, value):
        self._Systemname = value
    @property
    def GK(self):
        return self._GK
    @GK.setter
    def GK(self, value):
        self._GK = value
    @property
    def KG(self):
        return self._KG
    @KG.setter
    def KG(self, value):
        self._KG = value
    @property
    def KN01(self):
        return self._KN01
    @KN01.setter
    def KN01(self, value):
        self._KN01 = value
    @property
    def KN02(self):
        return self._KN02
    @KN02.setter
    def KN02(self, value):
        self._KN02 = value#
    @property
    def BIMID(self):
        return self._BIMID
    @BIMID.setter
    def BIMID(self, value):
        self._BIMID = value
    @property
    def Workset(self):
        return self._Workset
    @Workset.setter
    def Workset(self, value):
        self._Workset = value

Liste_Rohr = ObservableCollection[Exceldaten]()

def datenlesen(filepath):
    ex = Excel.ApplicationClass()
    _nova_Nr_Id = {}
    book = ex.Workbooks.Open(filepath)
    sheet = book.Worksheets['Rohr']
    rows = sheet.UsedRange.Rows.Count 
    for row in range(2,rows+1):
        tempclass = Exceldaten()
        sysname = sheet.Cells[row, 1].Value2
        GK = sheet.Cells[row, 2].Value2
        KG = str(int(sheet.Cells[row, 3].Value2))
        KN01 = str(int(sheet.Cells[row, 4].Value2))
        if len(KN01) == 1:
            KN01 = '0' + KN01
        KN02 = str(int(sheet.Cells[row, 5].Value2))
        if len(KN02) == 1:
            KN02 = '0' + KN02
        workset = sheet.Cells[row, 7].Value2
        bimid = GK + '_' + KG + '_' + KN01 + ' ' + KN02
        tempclass.Systemname = sysname
        tempclass.GK = GK
        tempclass.KG = KG
        tempclass.KN01 = KN01
        tempclass.KN02 = KN02
        tempclass.BIMID = bimid
        tempclass.Workset = workset      
        Liste_Rohr.Add(tempclass)
    book.Save()
    book.Close()
    Marshal.FinalReleaseComObject(sheet)
    Marshal.FinalReleaseComObject(book)
    ex.Quit()
    Marshal.FinalReleaseComObject(ex)
        

try:
    Adresse = bimid_config.bimid
    datenausexcel = {}
    try:
        datenlesen(Adresse)
    except Exception as e:
        logger.error(e)
except:
    pass


# ExcelBimId Pläne
class ExcelBimId(WPFWindow):
    def __init__(self, xaml_file_name,list_Rohr):
        self.list_Rohr = list_Rohr
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[Exceldaten]()
        self.read_config()
        self.Tempsource = None


        try:
            self.dataGrid.ItemsSource = self.list_Rohr
        except Exception as e:
            logger.error(e)

        self.systemsuche.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.excel_changed

    def read_config(self):
        try:
            self.Adresse.Text = str(bimid_config.bimid)
        except:
            self.Adresse.Text = bimid_config.bimid = ""

    def write_config(self):
        bimid_config.bimid = self.Adresse.Text.encode('utf-8')
        script.save_config()

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.systemsuche.Text
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.list_Rohr

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.list_Rohr:
                if item.Systemname.find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        # self.dataGrid.Items.Refresh()

    def excel_changed(self, sender, args):
        Liste_Rohr.Clear()
        try:
            datenlesen(self.Adresse.Text)
        except:
            pass
        self.list_Rohr = Liste_Rohr
        self.dataGrid.ItemsSource = Liste_Rohr

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "BIM-ID Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName
        self.write_config()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()
    
    def checkallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = True
        self.dataGrid.Items.Refresh()

    def uncheckallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = False
        self.dataGrid.Items.Refresh()

    def toggleallbb(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.bb
            item.bb = not value
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        self.Close()

windowExcelBimId = ExcelBimId("Window.xaml",Liste_Rohr)
windowExcelBimId.ShowDialog()


DictAusExcel = {}
for el in Liste_Rohr:
    if el.checked == True:
        DictAusExcel[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
        el.bb
    ]   

def DatenSchreiben_Bauteile(ids):
    for sys in ids.Keys:
        sysliste = ids[sys]
        daten = DictAusExcel[sys]
        bbschreiben = DictAusExcel[sys][6]
        elems = []
        for id in sysliste:
            els = doc.GetElement(id).PipingNetwork
            for ele in els:
                if ele.Category.Name in ['Rohr Systeme', 'Rohrdämmung']:
                    continue
                if not ele.Id.ToString() in elems:
                    elems.append(ele.Id.ToString())

        title = "{value}/{max_value} Elements in Rohr System " + sys
        step = int(len(elems)/1000) + 5
        tranitle = 'Daten schreiben (' + sys + ')'
        t = Transaction(doc,tranitle)
        t.Start()
        with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
            for n, eleid in enumerate(elems):
                elem = doc.GetElement(ElementId(int(eleid)))
                if pb.cancelled:
                    t.RollBack()
                    script.exit()
                pb.update_progress(n, len(elems))
                try:
                    elem.LookupParameter('IGF_X_Gewerkkürzel_Exemplar').Set(str(daten[0]))
                    elem.LookupParameter('IGF_X_KG_Exemplar').Set(int(daten[1]))
                    elem.LookupParameter('IGF_X_KN01_Exemplar').Set(int(daten[2]))
                    elem.LookupParameter('IGF_X_KN02_Exemplar').Set(int(daten[3]))
                    elem.LookupParameter('IGF_X_BIM-ID_Exemplar').Set(str(daten[4]))
                    if bbschreiben:
                        elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[daten[5]]))
                except Exception as e:
                    logger.error(e,elem.Id.ToString())
        t.Commit()


def DatenSchreiben_Systeme(ids,Category):
    tranitle = 'Daten schreiben (' + Category + ')'
    title = "{value}/{max_value} Daten in Kategorie " + Category
    step = int(len(ids)/100) + 1
    t = Transaction(doc,tranitle)
    t.Start()
    n_1 = 1
    with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
        for id in ids:
            if pb.cancelled:
                t.RollBack()
                script.exit()
            pb.update_progress(n_1, len(ids))
            n_1 += 1
            elem = doc.GetElement(id)
            systyp = elem.LookupParameter('Typ').AsValueString()
            elemtyp = doc.GetElement(elem.GetTypeId())
            try:
                daten = DictAusExcel[systyp]
                elemtyp.LookupParameter('IGF_X_Gewerkkürzel').Set(str(daten[0]))
                elemtyp.LookupParameter('IGF_X_Kostengruppe').Set(int(daten[1]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_1').Set(int(daten[2]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_2').Set(int(daten[3]))
                elemtyp.LookupParameter('IGF_X_BIM-ID').Set(str(daten[4]))
            except Exception as e:
                pass
    t.Commit()

# Rohr System
rohrsys = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
rohrsysids = rohrsys.ToElementIds()
rohrsys.Dispose()

syslistids = {}
for sysid in rohrsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.LookupParameter('Typ').AsValueString()
    if systyp in DictAusExcel.Keys:
        if systyp in syslistids.Keys:
            syslistids[systyp].append(sysid)
        else:
            syslistids[systyp] = [sysid]
if any(DictAusExcel):
    DatenSchreiben_Systeme(rohrsysids,'Rohr Systeme')
    DatenSchreiben_Bauteile(syslistids)
