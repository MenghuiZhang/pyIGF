# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
from Autodesk.Revit.DB import *
import rpw
import time
import clr
import System
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import FontWeights, FontStyles
from System.Windows.Media import Brushes, BrushConverter
from System.Windows.Forms import *
from System.Windows.Controls import *
from pyrevit.forms import WPFWindow
clr.AddReference("Microsoft.Office.Interop.Excel")
import Microsoft.Office.Interop.Excel as Excel
from System.Runtime.InteropServices import Marshal

start = time.time()

__title__ = "8.20 BIM-ID und Bearbeitsungsbereiche"
__doc__ = """BIM-ID und Bearbeitunsbereich aus excel in Modell schreiben"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()
bimid_config = script.get_config()
print(bimid_config)
from pyIGF_logInfo import getlog
getlog(__title__)

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# Bearbeitungsbereich
worksets = FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset)
Workset_dict = {}
for el in worksets:
    Workset_dict[el.Name] = el.Id.ToString()

# Exceldaten
class Exceldaten(object):
    def __init__(self):
        self.checked = False
        self.bb = False
        self.Systemname = ''
        self.GK = ''
        self.KG = ''
        self.KN01 = ''
        self.KN02 = ''
        self.BIMID = ''
        self.Workset = ''

    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def Systemname(self):
        return self._Systemname
    @Systemname.setter
    def Systemname(self, value):
        self._Systemname = value
    @property
    def GK(self):
        return self._GK
    @GK.setter
    def GK(self, value):
        self._GK = value
    @property
    def KG(self):
        return self._KG
    @KG.setter
    def KG(self, value):
        self._KG = value
    @property
    def KN01(self):
        return self._KN01
    @KN01.setter
    def KN01(self, value):
        self._KN01 = value
    @property
    def KN02(self):
        return self._KN02
    @KN02.setter
    def KN02(self, value):
        self._KN02 = value#
    @property
    def BIMID(self):
        return self._BIMID
    @BIMID.setter
    def BIMID(self, value):
        self._BIMID = value
    @property
    def Workset(self):
        return self._Workset
    @Workset.setter
    def Workset(self, value):
        self._Workset = value

Liste_Luft = ObservableCollection[Exceldaten]()
Liste_Alle = ObservableCollection[Exceldaten]()
Liste_Rohr = ObservableCollection[Exceldaten]()

def datenlesen(filepath,sheetname,Liste):
    ex = Excel.ApplicationClass()
    _nova_Nr_Id = {}
    book = ex.Workbooks.Open(filepath)
    sheet = book.Worksheets[sheetname]
    rows = sheet.UsedRange.Rows.Count
    for row in range(2,rows+1):
        tempclass = Exceldaten()
        sysname = sheet.Cells[row, 1].Value2
        GK = sheet.Cells[row, 2].Value2
        KG = str(int(sheet.Cells[row, 3].Value2))
        KN01 = str(int(sheet.Cells[row, 4].Value2))
        if len(KN01) == 1:
            KN01 = '0' + KN01
        KN02 = str(int(sheet.Cells[row, 5].Value2))
        if len(KN02) == 1:
            KN02 = '0' + KN02
        workset = sheet.Cells[row, 7].Value2
        bimid = GK + '_' + KG + '_' + KN01 + ' ' + KN02
        tempclass.Systemname = sysname
        tempclass.GK = GK
        tempclass.KG = KG
        tempclass.KN01 = KN01
        tempclass.KN02 = KN02
        tempclass.BIMID = bimid
        tempclass.Workset = workset
        Liste.Add(tempclass)
        Liste_Alle.Add(tempclass)
    book.Save()
    book.Close()
    Marshal.FinalReleaseComObject(sheet)
    Marshal.FinalReleaseComObject(book)
    ex.Quit()
    Marshal.FinalReleaseComObject(ex)


try:
    Adresse = bimid_config.bimid
    datenausexcel = {}
    try:
        datenlesen(Adresse,'Luft',Liste_Luft)
        datenlesen(Adresse,'Rohr',Liste_Rohr)
    except Exception as e:
        logger.error(e)
except:
    pass


# ExcelBimId Pläne
class ExcelBimId(WPFWindow):
    def __init__(self, xaml_file_name,liste_Luft,liste_Rohr,liste_All):
        self.liste_Luft = liste_Luft
        self.liste_All = liste_All
        self.liste_Rohr = liste_Rohr
        WPFWindow.__init__(self, xaml_file_name)
        self.tempcoll = ObservableCollection[Exceldaten]()
        self.altdatagrid = None
        self.read_config()

        try:
            self.dataGrid.ItemsSource = self.liste_All
            self.altdatagrid = self.liste_All
            self.backAll()
            self.click(self.alle)
        except Exception as e:
            logger.error(e)

        self.systemsuche.TextChanged += self.search_txt_changed
        self.Adresse.TextChanged += self.excel_changed
    def click(self,button):
        button.Background = BrushConverter().ConvertFromString("#FF707070")
        button.FontWeight = FontWeights.Bold
        button.FontStyle = FontStyles.Italic
    def back(self,button):
        button.Background  = Brushes.White
        button.FontWeight = FontWeights.Normal
        button.FontStyle = FontStyles.Normal
    def backAll(self):
        self.back(self.luft)
        self.back(self.rohr)
        self.back(self.alle)

    def rohr(self,sender,args):
        self.backAll()
        self.click(self.rohr)
        self.dataGrid.ItemsSource = self.liste_Rohr
        self.altdatagrid = self.liste_Rohr
        self.dataGrid.Items.Refresh()
    def luft(self,sender,args):
        self.backAll()
        self.click(self.luft)
        self.dataGrid.ItemsSource = self.liste_Luft
        self.altdatagrid = self.liste_Luft
        self.dataGrid.Items.Refresh()
    def alle(self,sender,args):
        self.backAll()
        self.click(self.alle)
        self.dataGrid.ItemsSource = self.liste_All
        self.altdatagrid = self.liste_All
        self.dataGrid.Items.Refresh()

    def read_config(self):
        try:
            self.Adresse.Text = str(bimid_config.bimid)
        except:
            self.Adresse.Text = bimid_config.bimid = ""

    def write_config(self):
        bimid_config.bimid = self.Adresse.Text.encode('utf-8')
        script.save_config()

    def search_txt_changed(self, sender, args):
        """Handle text change in search box."""
        self.tempcoll.Clear()
        text_typ = self.systemsuche.Text.upper()
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid

        else:
            if text_typ == None:
                text_typ = ''
            for item in self.altdatagrid:
                if item.Systemname.upper().find(text_typ) != -1:
                    self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()

    def excel_changed(self, sender, args):
        Liste_Luft.Clear()
        Liste_Rohr.Clear()
        Liste_Alle.Clear()
        try:
            datenlesen(self.Adresse.Text,'Luft',Liste_Luft)
            datenlesen(self.Adresse.Text,'Rohr',Liste_Rohr)
        except:
            pass
        self.liste_Luft = Liste_Luft
        self.dataGrid.ItemsSource = Liste_Luft

    def durchsuchen(self,sender,args):
        dialog = OpenFileDialog()
        dialog.Multiselect = False
        dialog.Title = "BIM-ID Datei suchen"
        dialog.Filter = "Excel Dateien|*.xls;*.xlsx"
        if dialog.ShowDialog() == DialogResult.OK:
            self.Adresse.Text = dialog.FileName
        self.write_config()

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()

    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()

    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()
    def checkallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = True
        self.dataGrid.Items.Refresh()

    def uncheckallbb(self,sender,args):
        for item in self.dataGrid.Items:
            item.bb = False
        self.dataGrid.Items.Refresh()

    def toggleallbb(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.bb
            item.bb = not value
        self.dataGrid.Items.Refresh()

    def ok(self,sender,args):
        self.Close()

windowExcelBimId = ExcelBimId("Window.xaml",Liste_Luft,Liste_Rohr,Liste_Alle)
windowExcelBimId.ShowDialog()


DictAusExcel_Luft = {}
for el in Liste_Luft:
    if el.checked == True:
        DictAusExcel_Luft[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
        el.bb
    ]

DictAusExcel_Rohr = {}
for el in Liste_Rohr:
    if el.checked == True:
        DictAusExcel_Rohr[el.Systemname] = [
        el.GK,
        el.KG,
        el.KN01,
        el.KN02,
        el.BIMID,
        el.Workset,
        el.bb
    ]

def DatenSchreiben_Bauteile(ids,DictAusExcel):
    t = Transaction(doc)
    for sys in ids.Keys:
        sysliste = ids[sys]
        daten = DictAusExcel[sys]
        bbschreiben = DictAusExcel[sys][6]
        elems = []
        for id in sysliste:
            els = None
            systyp = doc.GetElement(id).LookupParameter('Typ').AsValueString()
            # print(systyp)
            try:
                els = doc.GetElement(id).DuctNetwork
            except:
                els = doc.GetElement(id).PipingNetwork

            if not els:
                continue
            for ele in els:
                if ele.Category.Name in ['Luftkanal Systeme', 'Luftkanaldämmung außen', 'Luftkanaldämmung innen','Rohrdämmung']:
                    continue
                if not ele.Id.ToString() in elems:
                    # if ele.Category.Name == 'Rohre':
                    #     if ele.MEPSystem.LookupParameter('Typ').AsValueString() != systyp:
                    #         print(ele.Id.ToString(),id.ToString())
                    elems.append(ele.Id.ToString())

        title = "{value}/{max_value} Elements in System " + sys
        step = int(len(elems)/1000) + 5
        tranitle = 'Daten schreiben (' + sys + ')'

        t.Start(tranitle)
        if len(elems) > 0:
            with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
                for n, eleid in enumerate(elems):
                    elem = doc.GetElement(ElementId(int(eleid)))
                    if pb.cancelled:
                        t.RollBack()
                        script.exit()
                    pb.update_progress(n, len(elems))
                    if elem.Category.Name == 'Rohre':
                        if elem.MEPSystem.LookupParameter('Typ').AsValueString() != systyp:
                            print(elem.Id.ToString())
                    try:
                        elem.LookupParameter('IGF_X_Gewerkkürzel_Exemplar').Set(str(daten[0]))
                        elem.LookupParameter('IGF_X_KG_Exemplar').Set(int(daten[1]))
                        elem.LookupParameter('IGF_X_KN01_Exemplar').Set(int(daten[2]))
                        elem.LookupParameter('IGF_X_KN02_Exemplar').Set(int(daten[3]))
                        elem.LookupParameter('IGF_X_BIM-ID_Exemplar').Set(str(daten[4]))
                        if bbschreiben:
                            elem.LookupParameter('Bearbeitungsbereich').Set(int(Workset_dict[daten[5]]))
                    except Exception as e:
                        logger.error(e,elem.Id.ToString())
        t.Commit()


def DatenSchreiben_Systeme(ids,Category,DictAusExcel):
    tranitle = 'Daten schreiben (' + Category + ')'
    title = "{value}/{max_value} Daten in Kategorie " + Category
    step = int(len(ids)/100) + 1
    t = Transaction(doc,tranitle)
    t.Start()
    n_1 = 1
    with forms.ProgressBar(title=title,cancellable=True, step=step) as pb:
        for id in ids:
            if pb.cancelled:
                t.RollBack()
                script.exit()
            pb.update_progress(n_1, len(ids))
            n_1 += 1
            elem = doc.GetElement(id)
            systyp = elem.LookupParameter('Typ').AsValueString()
            elemtyp = doc.GetElement(elem.GetTypeId())
            try:
                daten = DictAusExcel[systyp]
                elemtyp.LookupParameter('IGF_X_Gewerkkürzel').Set(str(daten[0]))
                elemtyp.LookupParameter('IGF_X_Kostengruppe').Set(int(daten[1]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_1').Set(int(daten[2]))
                elemtyp.LookupParameter('IGF_X_Kennnummer_2').Set(int(daten[3]))
                elemtyp.LookupParameter('IGF_X_BIM-ID').Set(str(daten[4]))
            except Exception as e:
                pass
    t.Commit()

# Luft System
luftsys = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_DuctSystem).WhereElementIsNotElementType()
luftsysids = luftsys.ToElementIds()
luftsys.Dispose()

# Rohr System
rohrsys = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_PipingSystem).WhereElementIsNotElementType()
rohrsysids = rohrsys.ToElementIds()
rohrsys.Dispose()

syslistluftids = {}
for sysid in luftsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.LookupParameter('Typ').AsValueString()
    if systyp in DictAusExcel_Luft.Keys:
        if systyp in syslistluftids.Keys:
            syslistluftids[systyp].append(sysid)
        else:
            syslistluftids[systyp] = [sysid]

syslistrohrids = {}
for sysid in rohrsysids:
    elem = doc.GetElement(sysid)
    systyp = elem.LookupParameter('Typ').AsValueString()
    if systyp in DictAusExcel_Rohr.Keys:
        if systyp in syslistrohrids.Keys:
            syslistrohrids[systyp].append(sysid)
        else:
            syslistrohrids[systyp] = [sysid]

if any(DictAusExcel_Luft):
    DatenSchreiben_Systeme(luftsysids,'Luftkanal System',DictAusExcel_Luft)
    DatenSchreiben_Bauteile(syslistluftids,DictAusExcel_Luft)

if any(DictAusExcel_Rohr):
    DatenSchreiben_Systeme(rohrsysids,'Rohr System',DictAusExcel_Rohr)
    DatenSchreiben_Bauteile(syslistrohrids,DictAusExcel_Rohr)
