# coding: utf8
from Autodesk.Revit.UI import IExternalEventHandler,TaskDialog,TaskDialogResult,TaskDialogCommonButtons,ExternalEvent
import Autodesk.Revit.DB as DB
from System.Collections.ObjectModel import ObservableCollection
from pyrevit import forms


class SystemTyp(object):
    def __init__(self,elem,name,berechnung):
        self.elem = elem
        self.name = name
        self.berechnung = berechnung
        self.checked = False

DICT_BERECHNUNG = {
    'Alle': DB.Mechanical.SystemCalculationLevel.All,
    'Nur Volumenstrom': DB.Mechanical.SystemCalculationLevel.Flow,
    'Leistung': DB.Mechanical.SystemCalculationLevel.Performance,
    'Keine': DB.Mechanical.SystemCalculationLevel.None,
}

class AltDaten(object):
    def __init__(self,datum,daten):
        self.daten = daten
        self.datum = datum

class AltBerechnung(forms.WPFWindow):
    def __init__(self,Liste):
        self.Liste = Liste
        forms.WPFWindow.__init__(self,'altdaten.xaml')
        self.listview.ItemsSource = self.Liste
        
DICT_BERECHNUNG_UMGEKEHRT = {
    'All':'Alle',
    'Flow': 'Nur Volumenstrom',
    'Performance': 'Leistung',
    'None': 'Keine',
}


class KeineEinstellen(IExternalEventHandler):
    def __init__(self):
        self.Item_Luft = None
        self.Item_Rohr = None
        
    def Execute(self,app):        
        doc = app.ActiveUIDocument.Document
        t = DB.Transaction(doc,'Systemberechnung--Keine')
        t.Start()

        try:
            for el in self.Item_Luft:
                if el.checked:
                    try:
                        el.elem.CalculationLevel = DB.Mechanical.SystemCalculationLevel.None
                        
                    except:pass
            for el in self.Item_Rohr:
                if el.checked:
                    try:
                        el.elem.CalculationLevel = DB.Mechanical.SystemCalculationLevel.None
                        
                    except:pass
        except:pass

        t.Commit()
        t.Dispose()
    def GetName(self):
        return "setzt der Berechnungsmodus auf keine ein"

class Zuruecksetzen(IExternalEventHandler):
    def __init__(self):
        self.altdaten = None
        self.Luft = None
        self.Rohr = None
        
    def Execute(self,app):        
        doc = app.ActiveUIDocument.Document
        t = DB.Transaction(doc,'Systemberechnung--Zurück')
        t.Start()

        try:
            for el in self.altdaten.daten:
                try:
                    el.elem.CalculationLevel = DICT_BERECHNUNG[el.berechnung]
                except:pass

        except:pass

        t.Commit()
        t.Dispose()
    def GetName(self):
        return "setzt der Berechnungsmodus zurück"