# coding: utf8
import clr
from pyrevit import revit, DB, script, UI
from System.Collections.ObjectModel import ObservableCollection
from pyrevit.forms import WPFWindow
from System.Windows import FontWeights
from pyIGF_config import Server_config

__title__ = "Einstellungen"
__doc__ = """Grundeinstellungen für Systemtrennung festlegen.
Familie auswählen.
Version: 1.0"""
__author__ = "Menghui Zhang"

try:
    from pyIGF_logInfo import getlog
    getlog(__title__)
except:
    pass

class Familie(object):
    def __init__(self):
        self.SelID = 0
    @property
    def SelIS(self):
        return self._SelIS
    @SelIS.setter
    def SelIS(self,value):
        self._SelIS = value
    @property
    def SelID(self):
        return self._SelID
    @SelID.setter
    def SelID(self,value):
        self._SelID = value


class FamilieIS(object):
    def __init__(self):
        self.Name = ''
        self.id = 0
    @property
    def Name(self):
        return self._Name
    @Name.setter
    def Name(self,value):
        self._Name = value
    @property
    def id(self):
        return self._id
    @id.setter
    def id(self,value):
        self._id = value

logger = script.get_logger()
output = script.get_output()
uidoc = revit.uidoc
doc = revit.doc

Projekt = doc.ProjectInformation.Name
config = script.get_config('Systemtrennung_'+Projekt)


Server_Config = Server_config()
server_config = Server_Config.get_config('Systemtrennung_'+Projekt)



Liste_FAMIS_luft = ObservableCollection[FamilieIS]()
Liste_FAMIS_rohr = ObservableCollection[FamilieIS]()

coll = DB.FilteredElementCollector(doc).OfClass(clr.GetClrType(DB.Family))
Fam_luft = []
Fam_rohr = []

for el in coll:
    if el.FamilyCategoryId.ToString() == '-2008016':
        Fam_luft.append(el.Name)
    elif el.FamilyCategoryId.ToString() == '-2008055':
        Fam_rohr.append(el.Name)
coll.Dispose()

Fam_luft.sort()
Fam_rohr.sort()

dict_id_name_luft = {}
dict_name_id_luft = {}
dict_id_name_rohr = {}
dict_name_id_rohr = {}

for selid,el in enumerate(Fam_luft):
    temp = FamilieIS()
    temp.Name = el
    temp.id = selid
    dict_id_name_luft[selid] = el
    dict_name_id_luft[el] = selid
    Liste_FAMIS_luft.Add(temp)

for selid,el in enumerate(Fam_rohr):
    temp = FamilieIS()
    temp.Name = el
    temp.id = selid
    dict_id_name_rohr[selid] = el
    dict_name_id_rohr[el] = selid
    Liste_FAMIS_rohr.Add(temp)


def read_config(config):
    try:
        return config.Familie_luft,config.Familie_rohr
    except:
        try:
            config.Familie_luft = []
            config.Familie_rohr = []
            return [],[]
        except:
            return [],[]

config_user_luft,config_user_rohr = read_config(config)
config_server_luft,config_server_rohr = read_config(server_config)

Liste_user_luft = ObservableCollection[Familie]()
Liste_server_luft = ObservableCollection[Familie]()
Liste_user_rohr = ObservableCollection[Familie]()
Liste_server_rohr = ObservableCollection[Familie]()

for elem in Fam_luft:
    temp_user = Familie()
    temp_server = Familie()
    temp_user.SelIS = Liste_FAMIS_luft
    temp_server.SelIS = Liste_FAMIS_luft
    if elem in config_user_luft:
        temp_user.SelID = dict_name_id_luft[elem]
        Liste_user_luft.Add(temp_user)
    if elem in config_server_luft:
        temp_server.SelID = dict_name_id_luft[elem]
        Liste_server_luft.Add(temp_server)

for elem in Fam_rohr:
    temp_user = Familie()
    temp_server = Familie()
    temp_user.SelIS = Liste_FAMIS_rohr
    temp_server.SelIS = Liste_FAMIS_rohr
    if elem in config_user_rohr:
        temp_user.SelID = dict_name_id_rohr[elem]
        Liste_user_rohr.Add(temp_user)
    if elem in config_server_rohr:
        temp_server.SelID = dict_name_id_rohr[elem]
        Liste_server_rohr.Add(temp_server)


class PlaeneUI(WPFWindow):
    def __init__(self, xaml_file_name,liste_user_luft,liste_server_luft,liste_user_rohr,liste_server_rohr):
        self.liste_user_luft = liste_user_luft
        self.liste_server_luft = liste_server_luft
        self.liste_user_rohr = liste_user_rohr
        self.liste_server_rohr = liste_server_rohr
        WPFWindow.__init__(self, xaml_file_name)
        self.Title = 'Familie-Systemtrennung ({})'.format(Projekt)
        try:
            self.confi = config.getconfig
            if self.confi == True:
                self.ListView_Luft.ItemsSource = self.liste_server_luft
                self.ListView_Rohr.ItemsSource = self.liste_server_rohr
                self.serv.FontWeight = FontWeights.Bold
                self.conf = server_config
            else:
                self.loca.FontWeight = FontWeights.Bold
                self.conf = config
                self.ListView_Luft.ItemsSource = self.liste_user_luft
                self.ListView_Rohr.ItemsSource = self.liste_user_rohr
        except:
            self.conf = server_config
            try:
                config.getconfig = True
            except:
                pass
            self.serv.FontWeight = FontWeights.Bold
            self.ListView_Luft.ItemsSource = self.liste_server_luft
            self.ListView_Rohr.ItemsSource = self.liste_server_rohr
    
    @property
    def server_config(self):
        return Server_Config.get_config('Systemtrennung_'+Projekt)
    @property
    def user_config(self):
        return script.get_config('Systemtrennung_'+Projekt)
    
    def write_config_user(self):       
        try:
            self.user_config.Familie_luft = [dict_id_name_luft[item.SelID] for item in self.liste_user_luft]
        except:
            pass
        try:
            self.user_config.Familie_rohr = [dict_id_name_rohr[item.SelID] for item in self.liste_user_rohr]
        except:
            pass
        script.save_config()

    def write_config_server(self):       
        try:
            self.server_config.Familie_luft = [dict_id_name_luft[item.SelID] for item in self.liste_server_luft]
        except:
            pass
        try:
            self.server_config.Familie_rohr = [dict_id_name_rohr[item.SelID] for item in self.liste_server_rohr]
        except:
            pass
        Server_Config.save_config()
    
    def Abfrage(self):
        buttons = UI.TaskDialogCommonButtons.No | UI.TaskDialogCommonButtons.Yes
        Task = UI.TaskDialog.Show('Abfrage','Möchten Sie die Server-Einstellungen ändern?',buttons)
        if Task.ToString() == 'Yes':
            return True
        elif Task.ToString() == 'No':
            return False

    def Server_Pruefen(self):
        fam_luft = self.server_config.Familie_luft
        fam_rohr = self.server_config.Familie_rohr
        neu_luft = []
        neu_rohr = []
        for item in self.ListView_Luft.ItemsSource:
            name = dict_id_name_luft[item.SelID]
            neu_luft.append(name)
        for item in self.ListView_Rohr.ItemsSource:
            name = dict_id_name_rohr[item.SelID]
            neu_rohr.append(name)
 
        pr_luft = sorted(set(fam_luft)) == sorted(set(neu_luft))
        pr_rohr = sorted(set(fam_rohr)) == sorted(set(neu_rohr))

        return not(pr_luft and pr_rohr)
     
    def ok(self, sender, args):
        if self.user_config.getconfig:
            if self.Server_Pruefen():
                if self.Abfrage():
                    self.write_config_server()
                    script.save_config()
                    Server_Config.save_config()
                else:
                    try:
                        temp_coll_luft = ObservableCollection[Familie]()
                        temp_coll_rohr = ObservableCollection[Familie]()
                        for item in server_config.Familie_luft:
                            temp = Familie()
                            temp.SelID = dict_name_id_luft[item]
                            temp.SelIS = Liste_FAMIS_luft
                            temp_coll_luft.Add(temp)
                            self.ListView_Luft.ItemsSource = temp_coll_luft
                            self.liste_server_luft = temp_coll_luft
                        for item in server_config.Familie_rohr:
                            temp = Familie()
                            temp.SelID = dict_name_id_rohr[item]
                            temp.SelIS = Liste_FAMIS_rohr
                            temp_coll_rohr.Add(temp)
                            self.ListView_Rohr.ItemsSource = temp_coll_rohr
                            self.liste_server_rohr = temp_coll_rohr
                    except:
                        pass

        else:
            self.write_config_user()
        self.Close()

    def anwenden(self, sender, args):
        if self.user_config.getconfig:
            if self.Server_Pruefen():
                if self.Abfrage():
                    self.write_config_server()
                    Server_Config.save_config()
                    script.save_config()
                else:
                    try:
                        temp_coll_luft = ObservableCollection[Familie]()
                        temp_coll_rohr = ObservableCollection[Familie]()
                        for item in server_config.Familie_luft:
                            temp = Familie()
                            temp.SelID = dict_name_id_luft[item]
                            temp.SelIS = Liste_FAMIS_luft
                            temp_coll_luft.Add(temp)
                            self.ListView_Luft.ItemsSource = temp_coll_luft
                            self.liste_server_luft = temp_coll_luft
                        for item in server_config.Familie_rohr:
                            temp = Familie()
                            temp.SelID = dict_name_id_rohr[item]
                            temp.SelIS = Liste_FAMIS_rohr
                            temp_coll_rohr.Add(temp)
                            self.ListView_Rohr.ItemsSource = temp_coll_rohr
                            self.liste_server_rohr = temp_coll_rohr
                    except:
                        pass
        else:
            self.write_config_user()

    def abbrechen(self, sender, args):
        self.Close()

    def serve(self, sender, args):
        self.serv.FontWeight = FontWeights.Bold
        self.loca.FontWeight = FontWeights.Normal
        try:
            if not self.user_config.getconfig:
                self.write_config_user()
        except:
            pass
        try:
            self.user_config.getconfig = True
            script.save_config()
        except:
            pass
        self.ListView_Luft.ItemsSource = self.liste_server_luft
        self.ListView_Rohr.ItemsSource = self.liste_server_rohr
       
    def local(self, sender, args):
        self.loca.FontWeight = FontWeights.Bold
        self.serv.FontWeight = FontWeights.Normal
        try:
            if self.user_config.getconfig:
                if self.Server_Pruefen():
                    if self.Abfrage():
                        self.write_config_server()
                        Server_Config.save_config()  
                    else:
                        try:
                            temp_coll_luft = ObservableCollection[Familie]()
                            temp_coll_rohr = ObservableCollection[Familie]()
                            for item in server_config.Familie_luft:
                                temp = Familie()
                                temp.SelID = dict_name_id_luft[item]
                                temp.SelIS = Liste_FAMIS_luft
                                temp_coll_luft.Add(temp)
                                self.ListView_Luft.ItemsSource = temp_coll_luft
                                self.liste_server_luft = temp_coll_luft
                            for item in server_config.Familie_rohr:
                                temp = Familie()
                                temp.SelID = dict_name_id_rohr[item]
                                temp.SelIS = Liste_FAMIS_rohr
                                temp_coll_rohr.Add(temp)
                                self.ListView_Rohr.ItemsSource = temp_coll_rohr
                                self.liste_server_rohr = temp_coll_rohr
                        except:
                            pass
        except:
            pass
        try:
            self.user_config.getconfig = False
            script.save_config()
        except:
            pass
        self.ListView_Luft.ItemsSource = self.liste_user_luft
        self.ListView_Rohr.ItemsSource = self.liste_user_rohr
        
        
    def rueck(self, sender, args):
        try:
            config.Familie_luft = server_config.Familie_luft
            config.Familie_rohr = server_config.Familie_rohr
            temp_coll_luft = ObservableCollection[Familie]()
            temp_coll_rohr = ObservableCollection[Familie]()
            for item in config.Familie_luft:
                temp = Familie()
                temp.SelID = dict_name_id_luft[item]
                temp.SelIS = Liste_FAMIS_luft
                temp_coll_luft.Add(temp)
                self.ListView_Luft.ItemsSource = temp_coll_luft
                self.liste_user_luft = temp_coll_luft
            for item in config.Familie_rohr:
                temp = Familie()
                temp.SelID = dict_name_id_rohr[item]
                temp.SelIS = Liste_FAMIS_rohr
                temp_coll_rohr.Add(temp)
                self.ListView_Rohr.ItemsSource = temp_coll_rohr
                self.liste_user_rohr = temp_coll_rohr
        except:
            pass
        try:
            self.user_config.getconfig = False
        except:
            pass
        self.loca.FontWeight = FontWeights.Bold
        self.serv.FontWeight = FontWeights.Normal

    def add_luft(self, sender, args):
        temp = Familie()
        temp.SelIS = Liste_FAMIS_luft
        self.ListView_Luft.ItemsSource.Add(temp)
        
    def dele_luft(self, sender, args):
        if self.ListView_Luft.SelectedItem is not None:
            self.ListView_Luft.ItemsSource.Remove(self.ListView_Luft.SelectedItem)

    def add_rohr(self, sender, args):
        temp = Familie()
        temp.SelIS = Liste_FAMIS_rohr
        self.ListView_Rohr.ItemsSource.Add(temp)
        
    def dele_rohr(self, sender, args):
        if self.ListView_Rohr.SelectedItem is not None:
            self.ListView_Rohr.ItemsSource.Remove(self.ListView_Rohr.SelectedItem)
    
Planfenster = PlaeneUI("window.xaml",Liste_user_luft,Liste_server_luft,Liste_user_rohr,Liste_server_rohr)

try:
    Planfenster.ShowDialog()
except Exception as e:
    logger.error(e)
    Planfenster.Close()