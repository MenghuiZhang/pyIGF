# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
from Autodesk.Revit.DB import *
from System.Collections.ObjectModel import ObservableCollection
from pyrevit.forms import WPFWindow

__title__ = "Pläne erstellen"
__doc__ = """Pläne erstellen"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc


from pyIGF_logInfo import getlog
getlog(__title__)


plankopf_liste = []
plankopfid_dict = {}

# Planköpfe aus aktueller Projekt
TitleBlocks_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_TitleBlocks).WhereElementIsElementType()
TitleBlocks = TitleBlocks_collector.ToElementIds()
TitleBlocks_collector.Dispose()

for el in TitleBlocks:
    elem = doc.GetElement(el)
    familyandtyp = elem.get_Parameter(BuiltInParameter.SYMBOL_FAMILY_AND_TYPE_NAMES_PARAM).AsString()
    plankopfid_dict[familyandtyp] = el
    plankopf_liste.append(familyandtyp)

plankopf_liste.sort()

# Bildausschnitt aus aktueller Projekt
Bildaus_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_VolumeOfInterest).WhereElementIsNotElementType()
Bildausschnitt = Bildaus_collector.ToElementIds()
Bildaus_collector.Dispose()
ausschnitt_liste = []
ausschnitt_dict = {}

for el in Bildausschnitt:
    elem = doc.GetElement(el)
    family = elem.Name
    ausschnitt_dict[familyandtyp] = el
    ausschnitt_liste.append(family)

ausschnitt_liste.sort()
ausschnitt_liste.insert(0,'Keine')
ausschnitt_liste.insert(0,'None')

# Views aus aktueller Projekt
views_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Views).WhereElementIsNotElementType()
views = views_collector.ToElementIds()
views_collector.Dispose()
view_liste = []
Legenden_liste = []
Legenden_dict  = {}

for el in views:
    elem = doc.GetElement(el)
    typ = elem.ViewType.ToString()
    if typ in ['FloorPlan','CeilingPlan','Elevation','ThreeD','Section','Detail']:
        view_liste.append(el)
    elif typ == 'Legend':
        Legenden_liste.append(elem.Name)
        Legenden_dict[elem.Name] = el

Legenden_liste.sort()

# Viewports aus aktueller Projekt
Viewport_liste = []
Viewport_dict = {}
viewports_collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Viewports).WhereElementIsNotElementType()
viewports = viewports_collector.ToElementIds()
viewports_collector.Dispose()
for el in viewports:
    viewtypes = doc.GetElement(el).GetValidTypes()
    for i in viewtypes:
        name = doc.GetElement(i)\
          .get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
        Viewport_dict[name] = i
        Viewport_liste.append(name)
    break
Viewport_liste.sort()

class Views(object):
    def __init__(self):
        self.checked = False
        self.Bildausschnitt = ''
        self.ElementID = ''
        self.Group = ''
        self.Mcate = ''
        self.Subcate = ''
        self.ansichtname = ''
        self.Ansichtstyp = ''
        self.Legend = ''

    @property
    def Group(self):
        return self._Group
    @Group.setter
    def Group(self, value):
        self._Group = value
    @property
    def Ansichtstyp(self):
        return self._Ansichtstyp
    @Ansichtstyp.setter
    def Ansichtstyp(self, value):
        self._Ansichtstyp = value
    @property
    def Legend(self):
        return self._Legend
    @Legend.setter
    def Legend(self, value):
        self._Legend = value
    @property
    def Mcate(self):
        return self._Mcate
    @Mcate.setter
    def Mcate(self, value):
        self._Mcate = value
    @property
    def Subcate(self):
        return self._Subcate
    @Subcate.setter
    def Subcate(self, value):
        self._Subcate = value
    @property
    def ansichtname(self):
        return self._ansichtname
    @ansichtname.setter
    def ansichtname(self, value):
        self._ansichtname = value
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self, value):
        self._checked = value
    @property
    def ElementID(self):
        return self._ElementID
    @ElementID.setter
    def ElementID(self, value):
        self._ElementID = value
    @property
    def Bildausschnitt(self):
        return self._Bildausschnitt
    @Bildausschnitt.setter
    def Bildausschnitt(self, value):
        self._Bildausschnitt = value   

Liste_Views = ObservableCollection[Views]()
Auswahldict = {}

for viewid in view_liste:
    elem = doc.GetElement(viewid)
    tempclass = Views()
    tempclass.ansichtname = elem.Name
    tempclass.ElementID = viewid
    try:
        if not elem.LookupParameter('Bildausschnitt'):
            tempclass.Bildausschnitt = 'None'
        else:
            if elem.LookupParameter('Bildausschnitt').AsValueString():
                tempclass.Bildausschnitt = elem.LookupParameter('Bildausschnitt').AsValueString()
            else:
                tempclass.Bildausschnitt = 'keine'
    except:
        pass
    try:
        group = elem.LookupParameter('000_000_152_Ansichtsgruppe').AsString()
        if not group:
            group = '???'
        tempclass.Group = group
        mcate = elem.LookupParameter('Unterdisziplin').AsString()
        if not mcate:
            mcate = '???'
        tempclass.Mcate = mcate
        scate = elem.get_Parameter(BuiltInParameter.VIEW_TYPE).AsString()
        if not scate:
            scate = '???'
        tempclass.Subcate = scate
        if not group in Auswahldict.Keys:
            Auswahldict[group] = {}
        if not mcate in Auswahldict[group].Keys:
            Auswahldict[group][mcate] = []
        if not scate in Auswahldict[group][mcate]:
            Auswahldict[group][mcate].append(scate)
    except Exception as e:
        logger.error(e) 
     
    Liste_Views.Add(tempclass)


keys1 = Auswahldict.Keys[:]
keys1.sort()
keys1.append('Keine')

keys2 = []
keys3 = []
global create 
create = False

global plankopf 
plankopf = ''

global zuschneid 
zuschneid = '10'

global Oben 
Oben = '5'

global Links 
Links = '20'



class PlaeneUI(WPFWindow):
    def __init__(self, xaml_file_name,liste_views):
        self.liste_views = liste_views
        WPFWindow.__init__(self, xaml_file_name)
        self.dataGrid.ItemsSource = liste_views
        self.tempcoll = ObservableCollection[Views]()
        self.leercoll = ObservableCollection[Views]()
        self.dataGrid.Columns[2].ItemsSource = ausschnitt_liste
        self.dataGrid.Columns[3].ItemsSource = Viewport_liste
        self.dataGrid.Columns[4].ItemsSource = Legenden_liste
        self.Plankopf.ItemsSource = plankopf_liste
        self.altdatagrid = liste_views
        self.group.ItemsSource = keys1
        self.main.ItemsSource = keys2
        self.sub.ItemsSource = keys3
        self.zuschneid.Text = str(10)
        self.Oben.Text = str(5)
        self.Links.Text = str(20)

        self.plansuche.TextChanged += self.auswahl_txt_changed
        self.group.SelectionChanged += self.auswahl_txt_changed
        self.group.SelectionChanged += self.auswahl_group_changed
        self.sub.SelectionChanged += self.auswahl_txt_changed
        self.main.SelectionChanged += self.auswahl_txt_changed
        self.main.SelectionChanged += self.auswahl_main_changed

        self.prevalue4 = ''
        self.newvalue4 = ''

        self.prevalue3 = ''
        self.newvalue3 = ''

    def auswahl_group_changed(self,sender,args):
        group = ''
        temp_key2 = []
        temp_key3 = []
        try:
            group = self.group.SelectedItem.ToString()
        except:
            pass
        try:
            temp_key2 = Auswahldict[group].Keys[:]
            temp_key2.sort()
            temp_key2.append('Keine')
            
            self.main.ItemsSource = temp_key2
            self.main.Text = 'Keine'
            self.sub.ItemsSource = temp_key3
        except:
            self.sub.ItemsSource = temp_key3
    def auswahl_main_changed(self,sender,args):
        main = ''
        try:
            main = self.main.SelectedItem.ToString()
        except:
            pass
        group = ''
        try:
            group = self.group.SelectedItem.ToString()
        except:
            pass
        try:
            keys3 = Auswahldict[group][main][:]
            keys3.sort()
            keys3.append('Keine')
            
            self.sub.Text = 'Keine'
            self.sub.ItemsSource = keys3
        except:
            self.sub.ItemsSource = []
            self.sub.Text = ''

        
    def auswahl_txt_changed(self, sender, args):
        self.tempcoll.Clear()
        text_typ = self.plansuche.Text.upper()
        group = ''
        sub = ''
        main = ''
        try:
            group = self.group.SelectedItem.ToString()
        except:
            pass
        try:
            sub = self.sub.SelectedItem.ToString()
        except:
            pass
        try:
            main = self.main.SelectedItem.ToString()
        except:
            pass
        
        if not group:
            group = self.group.Text = ''
        if not sub:
            sub = self.sub.Text = ''
        if not main:
            main = self.main.Text = ''
        
        if text_typ in ['',None]:
            self.dataGrid.ItemsSource = self.altdatagrid
            text_typ = self.plansuche.Text = ''

        for item in self.altdatagrid:
            if item.ansichtname.upper().find(text_typ) != -1:
                if group in ['','Keine']:
                    self.tempcoll.Add(item)
                else:
                    if item.Group == group:
                        if main in ['','Keine']:
                            self.tempcoll.Add(item)
                        else:
                            if main == item.Mcate:
                                if sub in ['','Keine']:
                                    self.tempcoll.Add(item)
                                else:
                                    if sub == item.Subcate:
                                        self.tempcoll.Add(item)
            self.dataGrid.ItemsSource = self.tempcoll
        self.dataGrid.Items.Refresh()
    
    def dataGrid_BeginningEdit(self,sender,args):
        if args.Column.DisplayIndex == 3:
            self.prevalue3 = args.Column.GetCellContent(args.Row).Text
        elif args.Column.DisplayIndex == 4:
            self.prevalue4 = args.Column.GetCellContent(args.Row).Text

    def dataGrid_CellEditEnding(self,sender,args):
        if args.Column.DisplayIndex == 0:
            value = args.Row.Item.checked
            args.Row.Item.checked = not value
        elif args.Column.DisplayIndex == 3:
            self.newvalue3 = args.EditingElement.Text
            if self.newvalue3 != self.prevalue3:
                args.Row.Item.Ansichtstyp = self.newvalue3
                self.prevalue3 = ''
            for item in self.dataGrid.Items:
                if item.checked:
                    if item.Ansichtstyp in ['', None]:
                        item.Ansichtstyp = self.newvalue3
        elif args.Column.DisplayIndex == 4:
            self.newvalue4 = args.EditingElement.Text
            if self.newvalue4 != self.prevalue4:
                self.prevalue4 = ''
                args.Row.Item.Legend = self.newvalue4
            for item in self.dataGrid.Items:
                if item.checked:
                    if item.Legend in ['', None]:
                        item.Legend = self.newvalue4

        self.dataGrid.ItemsSource = self.leercoll
        if self.tempcoll.Count >= 1:
            self.dataGrid.ItemsSource = self.tempcoll
        else:
            self.dataGrid.ItemsSource = self.liste_views

    def checkall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = True
        self.dataGrid.Items.Refresh()


    def uncheckall(self,sender,args):
        for item in self.dataGrid.Items:
            item.checked = False
        self.dataGrid.Items.Refresh()


    def toggleall(self,sender,args):
        for item in self.dataGrid.Items:
            value = item.checked
            item.checked = not value
        self.dataGrid.Items.Refresh()

    def aktu(self,sender,args):
        global create 
        create = True
        global zuschneid 
        zuschneid = self.zuschneid.Text
        global Oben 
        Oben = self.Oben.Text
        global Links 
        Links = self.Links.Text

        global plankopf
        try:
            plankopf = self.Plankopf.SelectedItem.ToString()
        except:
            plankopf = ''
        if not plankopf:
            UI.TaskDialog.Show('Fehler','Kein Plankopf ausgewählt')
        
        else:
            self.Close()
        
    def close(self,sender,args):
        self.Close()

Planfenster = PlaeneUI("window.xaml",Liste_Views)
Planfenster.ShowDialog()

if not create:
    script.exit()

Liste_Pläne = []
for ele in Liste_Views:
    if ele.checked:
        Liste_Pläne.append([ele.ansichtname,ele.Bildausschnitt,ele.ElementID,ele.Ansichtstyp,ele.Legend])

if any(Liste_Pläne):
    t_raster = DB.Transaction(doc,'Raster anpassen')
    t_raster.Start()
    with forms.ProgressBar(title='{value}/{max_value} Ansichten',cancellable=True, step=1) as pb:
        for n, elem in enumerate(Liste_Pläne):
            if pb.cancelled:
                t_raster.RollBack()
                script.exit()
            pb.update_progress(n, len(Liste_Pläne))
            view = doc.GetElement(elem[2])
            try:
                cropbox = view.GetCropRegionShapeManager()
                cropbox.TopAnnotationCropOffset = float(zuschneid) / 304.8
                cropbox.BottomAnnotationCropOffset = float(zuschneid) / 304.8
                cropbox.RightAnnotationCropOffset = float(zuschneid) / 304.8
                cropbox.LeftAnnotationCropOffset = float(zuschneid) / 304.8
            except:
                pass
            rasters_collector = DB.FilteredElementCollector(doc,elem[2]).OfCategory(DB.BuiltInCategory.OST_Grids).WhereElementIsNotElementType()
            rasters = rasters_collector.ToElementIds()
            rasters_collector.Dispose()
            box = view.get_BoundingBox(view)
            max_X = box.Max.X
            max_Y = box.Max.Y
            min_X = box.Min.X
            min_Y = box.Min.Y
            for rasid in rasters:
                raster = doc.GetElement(rasid)
                raster.Pinned = False
                gridCurves = raster.GetCurvesInView(DB.DatumExtentType.ViewSpecific, view)
                if not gridCurves:
                    continue
                for gridCurve in gridCurves:
                    start = gridCurve.GetEndPoint( 0 )
                    end = gridCurve.GetEndPoint( 1 )
                    X1 = start.X
                    Y1 = start.Y
                    Z1 = start.Z
                    X2 = end.X
                    Y2 = end.Y
                    Z2 = end.Z
                    newStart = None
                    newEnd = None
                    newLine = None
                    if abs(X1-X2) > 1:
                        newStart = DB.XYZ(max_X,Y1,Z1)
                        newEnd = DB.XYZ(min_X,Y2,Z2)
                    if abs(Y1-Y2) > 1:
                        newStart = DB.XYZ(X1,max_Y,Z1)
                        newEnd = DB.XYZ(X2,min_Y,Z2)
                    if all([newStart,newEnd]):
                        newLine = DB.Line.CreateBound( newStart, newEnd )
                    if newLine:
                        raster.SetCurveInView(DB.DatumExtentType.ViewSpecific, view, newLine )
                raster.Pinned = True
    t_raster.Commit()

    t_Plan = DB.Transaction(doc,'Pläne erstellen')
    t_Plan.Start()
    with forms.ProgressBar(title='{value}/{max_value} Pläne erstellt',cancellable=True, step=1) as pb1:
        plankopfid = plankopfid_dict[plankopf]
        for n1, elem1 in enumerate(Liste_Pläne):
            if pb1.cancelled:
                t_Plan.RollBack()
                script.exit()
            pb1.update_progress(n1, len(Liste_Pläne))
            viewsheet = DB.ViewSheet.Create(doc,plankopfid)
            location = DB.XYZ((viewsheet.Outline.Max.U+viewsheet.Outline.Min.U)/2,(viewsheet.Outline.Max.V+viewsheet.Outline.Min.V)/2,0)
            try:
                viewport = DB.Viewport.Create(doc,viewsheet.Id,elem1[2],location)
                try:
                    typeid = Viewport_dict[elem1[3]]
                    viewport.ChangeTypeId(typeid)
                except:
                    pass
                x_move = viewport.get_BoundingBox(viewsheet).Max.X + float(Links) / 304.8 - viewsheet.Outline.Max.U
                y_move = viewsheet.Outline.Max.V - viewport.get_BoundingBox(viewsheet).Max.Y - float(Oben) / 304.8
                xyz_move = DB.XYZ(x_move,y_move,0)
                viewport.Location.Move(xyz_move)
            except Exception as e:
                logger.error(e)
                doc.Delete(viewsheet.Id)

            try:
                viewport1 = DB.Viewport.Create(doc,viewsheet.Id,Legenden_dict[elem1[4]],location)
                try:
                    typeid = Viewport_dict['Kein Titel']
                    viewport1.ChangeTypeId(typeid)
                except:
                    for e in Viewport_dict.values():
                        try:
                            doc.GetElement(e).GetLabelOutline()
                        except:
                            viewport1.ChangeTypeId(e)
                            break
                x1_move = viewsheet.Outline.Max.U - viewport1.get_BoundingBox(viewsheet).Max.X - float(Oben) / 304.8 
                y1_move = viewsheet.Outline.Max.V - viewport1.get_BoundingBox(viewsheet).Max.Y - float(Oben) / 304.8
                xyz1_move = DB.XYZ(x1_move,y1_move,0)
                viewport1.Location.Move(xyz1_move)
            except Exception as e:
                logger.error(e)

                
    t_Plan.Commit()