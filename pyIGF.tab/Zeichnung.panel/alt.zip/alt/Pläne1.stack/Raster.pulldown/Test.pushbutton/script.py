# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
from Autodesk.Revit.DB import Transaction
from System.Collections.ObjectModel import ObservableCollection
from pyrevit.forms import WPFWindow

__title__ = "Pläne anpassen"
__doc__ = """Raster anpassen"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

from pyIGF_logInfo import getlog
getlog(__title__)

coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Sheets).WhereElementIsNotElementType()
sheetsid = coll.ToElementIds()
coll.Dispose()

ansichtytyp_coll = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Viewports).WhereElementIsNotElementType()
AnsichtsfensterType = {}
AnsichtsfensterType_liste = []

for view in ansichtytyp_coll:
    viewtypes = view.GetValidTypes()
    for i in viewtypes:
        name = doc.GetElement(i)\
          .get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
        AnsichtsfensterType_liste.append(name)
        AnsichtsfensterType[name] = i
    break

AnsichtsfensterType_liste.sort()
ansichtytyp_coll.Dispose()

class plan(object):
    def __init__(self):
        self.checked = False
        self.plannummer = ''
        self.Elementid = ''
    @property
    def checked(self):
        return self._checked
    @checked.setter
    def checked(self,value):
        self._checked = value
    @property
    def plannummer(self):
        return self._plannummer
    @plannummer.setter
    def plannummer(self,value):
        self._plannummer = value
    @property
    def Elementid(self):
        return self._Elementid
    @Elementid.setter
    def Elementid(self,value):
        self._Elementid = value

Liste_Plan = ObservableCollection[plan]()
for el in sheetsid:
    sheet = doc.GetElement(el)
    Nr = sheet.get_Parameter(DB.BuiltInParameter.SHEET_NUMBER).AsString()
    Name = sheet.get_Parameter(DB.BuiltInParameter.SHEET_NAME).AsString()
    temp = plan()
    temp.plannummer = Nr + ' - ' + Name
    temp._Elementid = el
    Liste_Plan.Add(temp)

global Ansichtstyp
global Haupt
global Legende
global Versatz
global Raster
global Hauptecke
global Legendeecke

class PlaeneUI(WPFWindow):
    def __init__(self, xaml_file_name,liste_plan):
        self.liste_plan = liste_plan
        WPFWindow.__init__(self, xaml_file_name)
        self.ListPlan.ItemsSource = liste_plan
        self.ansichtstyp.ItemsSource = AnsichtsfensterType_liste
        self.Versatz.Text = '10'

        self.tempcoll = ObservableCollection[plan]()

        self.plansuche.TextChanged += self.auswahl_txt_changed

    def auswahl_txt_changed(self, sender, args):
        self.tempcoll.Clear()
        text_typ = self.plansuche.Text.upper()
        
        if text_typ in ['',None]:
            self.ListPlan.ItemsSource = self.liste_plan
            text_typ = self.plansuche.Text = ''

        for item in self.liste_plan:
            if item.plannummer.upper().find(text_typ) != -1:
                self.tempcoll.Add(item)                                     
            self.ListPlan.ItemsSource = self.tempcoll
        self.ListPlan.Items.Refresh()

    def check(self,sender,args):
        for item in self.ListPlan.Items:
            item.checked = True
        print(self.ListPlan.SelectedItems.Count)
        self.ListPlan.Items.Refresh()


    def uncheck(self,sender,args):
        for item in self.ListPlan.Items:
            item.checked = False
        self.ListPlan.Items.Refresh()


    def toggle(self,sender,args):
        for item in self.ListPlan.Items:
            value = item.checked
            item.checked = not value
        self.ListPlan.Items.Refresh()

    
    def checkedchanged(self, sender, args):
        Checked = sender.IsChecked
        if self.ListPlan.SelectedItem is not None:
            try:
                if sender.DataContext in self.ListPlan.SelectedItems:
                    for item in self.ListPlan.SelectedItems:
                        item.checked = Checked
                    self.ListPlan.Items.Refresh()
                else:
                    pass
            except:
                pass

    def aktu(self,sender,args):
        
        global Ansichtstyp
        global Haupt
        global Legende
        global Versatz
        global Raster
        global Hauptecke
        global Legendeecke
        Raster = self.raster.IsChecked
        Hauptecke = self.Haupt.IsChecked
        Legendeecke = self.legend.IsChecked
        Haupt = self.hauptansicht.IsChecked
        Legende = self.legende.IsChecked
        Versatz = self.Versatz.Text
        try:
            Ansichtstyp = self.ansichtstyp.SelectedItem.ToString()
        except:
            Ansichtstyp = None
        if any([Legende,Haupt]):
            if not Ansichtstyp:
                UI.TaskDialog.Show('Fehler','Kein Ansichtstyp ausgewählt')
            else:
                self.Close()
        else:
            self.Close()
        
    def close(self,sender,args):
        self.Close()

Planfenster = PlaeneUI("window.xaml",Liste_Plan)
Planfenster.ShowDialog()

Bearbeiten_Liste = []
for el in Liste_Plan:
    if el.checked:
        Bearbeiten_Liste.append(el.Elementid)

if len(Bearbeiten_Liste) == 0:
    UI.TaskDialog.Show('Fehler','Kein Plan ausgewählt')
    script.exit()
if not any([Raster,Haupt,Legende,Versatz,Hauptecke,Legendeecke]):
    script.exit()

t = DB.Transaction(doc, ' Pläne anpassen')
t.Start()
with forms.ProgressBar(title="{value}/{max_value} Pläne ausgewählt",cancellable=True, step=1) as pb:
    for n, planid in enumerate(Bearbeiten_Liste):
        if pb.cancelled:
            t.RollBack()
            script.exit()
        pb.update_progress(n, len(Bearbeiten_Liste))
        Plan = doc.GetElement(planid)

        viewports = Plan.GetAllViewports()
        Liste_Viewpot = {'Grundrisse':[],'Legenden':[]}
        for viewid in viewports:
            View = doc.GetElement(viewid)
            View_family = View.get_Parameter(DB.BuiltInParameter.VIEW_FAMILY).AsString()
            if View_family == 'Grundrisse':
                Liste_Viewpot['Grundrisse'].append(viewid)
            elif View_family == 'Legenden':
                Liste_Viewpot['Legenden'].append(viewid)
        for key in Liste_Viewpot.keys():
            for viewid in Liste_Viewpot[key]:
                View = doc.GetElement(viewid)
                View.Pinned = False
                if key == 'Grundrisse':
                    if Ansichtstyp and Haupt:
                        try:
                            View.ChangeTypeId(AnsichtsfensterType[Ansichtstyp])
                        except Exception as e0:
                            logger.error(e0)
                            logger.error('AnsichtsfensterType der Hauptansicht')
                    ansicht = doc.GetElement(View.ViewId)
                    if Versatz:
                        try:
                            cropbox = ansicht.GetCropRegionShapeManager()
                            cropbox.TopAnnotationCropOffset = float(Versatz) / 304.8
                            cropbox.BottomAnnotationCropOffset = float(Versatz) / 304.8
                            cropbox.RightAnnotationCropOffset = float(Versatz) / 304.8
                            cropbox.LeftAnnotationCropOffset = float(Versatz) / 304.8
                        except Exception as e1:
                            logger.error(e1)
                            logger.error('Versatz der Beschriftungszuschnitt')
                    if Raster:
                        try:
                            box = ansicht.get_BoundingBox(ansicht)
                            max_X = box.Max.X
                            max_Y = box.Max.Y
                            min_X = box.Min.X
                            min_Y = box.Min.Y
                        
                            rasters_collector = DB.FilteredElementCollector(doc,ansicht.Id) \
                                .OfCategory(DB.BuiltInCategory.OST_Grids)\
                                .WhereElementIsNotElementType()
                            rasters = rasters_collector.ToElementIds()
                            rasters_collector.Dispose()
                            for rasterid in rasters:
                                raster = doc.GetElement(rasterid)
                                raster.Pinned = False
                                gridCurves = raster.GetCurvesInView(DB.DatumExtentType.ViewSpecific, ansicht)
                                if not gridCurves:
                                    continue
                                for gridCurve in gridCurves:
                                    start = gridCurve.GetEndPoint( 0 )
                                    end = gridCurve.GetEndPoint( 1 )
                                    X1 = start.X
                                    Y1 = start.Y
                                    Z1 = start.Z
                                    X2 = end.X
                                    Y2 = end.Y
                                    Z2 = end.Z
                                    newStart = None
                                    newEnd = None
                                    newLine = None
                                    if abs(X1-X2) > 1:
                                        newStart = DB.XYZ(max_X,Y1,Z1)
                                        newEnd = DB.XYZ(min_X,Y2,Z2)
                                    if abs(Y1-Y2) > 1:
                                        newStart = DB.XYZ(X1,max_Y,Z1)
                                        newEnd = DB.XYZ(X2,min_Y,Z2)
                                    if all([newStart,newEnd]):
                                        newLine = DB.Line.CreateBound( newStart, newEnd )
                                    if newLine:
                                        raster.SetCurveInView(DB.DatumExtentType.ViewSpecific, ansicht, newLine )
                                raster.Pinned = True
                        except Exception as e2:
                            logger.error(e2)
                            logger.error('Raster')
                        doc.Regenerate()
                    if Hauptecke:
                        if len(Liste_Viewpot[key]) <= 1:
                            try:
                                x_move = Plan.Outline.Min.U - View.get_BoundingBox(Plan).Min.X + float(20) / 304.8
                                y_move = Plan.Outline.Max.V - View.get_BoundingBox(Plan).Max.Y - float(5) / 304.8
                                xyz_move = DB.XYZ(x_move,y_move,0)
                                View.Location.Move(xyz_move)
                            except Exception as e3:
                                logger.error(e3)
                                logger.error('Verschiebung von Hauptansicht')
                        else:
                            plannr = Plan.get_Parameter(DB.BuiltInParameter.SHEET_NUMBER).AsString() + ' - ' + \
                                    Plan.get_Parameter(DB.BuiltInParameter.SHEET_NAME).AsString()
                            logger.error('Mehr als 1 Grundrisse in Plan {}'.format(plannr))
                elif key == 'Legenden':
                    if Ansichtstyp and Legende:
                        try:
                            View.ChangeTypeId(AnsichtsfensterType[Ansichtstyp])
                        except Exception as e4:
                            logger.error(e4)
                            logger.error('AnsichtsfensterType von Legende')
                    if Legendeecke:
                        if len(Liste_Viewpot[key]) <= 1:
                            try:
                                x_move1 = Plan.Outline.Max.U - View.get_BoundingBox(Plan).Max.X - float(5) / 304.8
                                y_move1 = Plan.Outline.Max.V - View.get_BoundingBox(Plan).Max.Y - float(5) / 304.8
                                xyz_move1 = DB.XYZ(x_move1,y_move1,0)
                                View.Location.Move(xyz_move1)
                            except Exception as e5:
                                logger.error(e5)
                                logger.error('Verschiebung von Legende')
                        else:
                            plannr = Plan.get_Parameter(DB.BuiltInParameter.SHEET_NUMBER).AsString() + ' - ' + \
                                    Plan.get_Parameter(DB.BuiltInParameter.SHEET_NAME).AsString()
                            logger.error('Mehr als 1 Legenden in Plan {}'.format(plannr))
                        
                View.Pinned = True
t.Commit()