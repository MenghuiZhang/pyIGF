# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

start = time.time()


__title__ = "9.41 MFC_Planindex"
__doc__ = """MFC_Planindex"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc

# MEP Räume aus aktueller Projekt
plaene_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
    .WhereElementIsNotElementType()
plaene = plaene_collector.ToElementIds()

plaen_collector = DB.FilteredElementCollector(doc) \
    .OfCategory(DB.BuiltInCategory.OST_Sheets) \
    .WhereElementIsNotElementType()
plaen = plaen_collector.ToElementIds()



def get_value(param):
    """Konvertiert Einheiten von internen Revit Einheiten in Projekteinheiten"""

    value = revit.query.get_param_value(param)

    try:
        unit = param.DisplayUnitType

        value = DB.UnitUtils.ConvertFromInternalUnits(
            value,
            unit)

    except Exception as e:
        pass

    return value

with forms.ProgressBar(title='{value}/{max_value} Vorabzug',
                       cancellable=True, step=5) as pb:
    n = 0

    t = Transaction(doc, "Vorabzug")
    t.Start()


    def Vorabzug(input_para):
        out = 'P'
        if input_para == True:
            out = 'V'
        return out

    list = []
    for Item in plaene_collector:
        if pb.cancelled:
            script.exit()
        n += 1
        pb.update_progress(n, len(plaene))
        Nummer = get_value(Item.LookupParameter('Plannummer'))
        tempel = get_value(Item.Symbol.LookupParameter('Vorabzugsstempel'))
        if not tempel:
            tempel = get_value(Item.LookupParameter('Vorabzugsstempel'))
        V_or_P = Vorabzug(tempel)

        if len(Nummer) > 10:
            KN01 = Nummer[:len(Nummer) - 3]
            Neu_Nummer = KN01 + V_or_P + Nummer[len(Nummer) - 2:]
            if Neu_Nummer in list:
                logger.error('{} ist bereits verwendet. Aktuelle Nummer: {}'.format(Neu_Nummer,Nummer))
            else:
                if Item.LookupParameter('Plannummer'):
                    Item.LookupParameter('Plannummer').Set(Neu_Nummer)
                    list.append(Neu_Nummer)
    t.Commit()

with forms.ProgressBar(title='{value}/{max_value} Index',
                       cancellable=True, step=5) as pb:
    n = 0
    t = Transaction(doc, "Index")
    t.Start()

    def Neunummer(indexnummer):
        index = '00'
        if indexnummer:
            if len(indexnummer) == 1:
                index = '0' + str(indexnummer)
            elif len(indexnummer) == 2:
                index = str(indexnummer)
        return index


    list = []
    for Item in plaen_collector:
        if pb.cancelled:
            script.exit()
        n += 1
        pb.update_progress(n, len(plaen))
        Nummer = get_value(Item.LookupParameter('Plannummer'))
        Index = get_value(Item.LookupParameter('Aktuelle Änderung'))
        Neu_Index = Neunummer(Index)

        if len(Nummer) > 10:
            Neu_Nummer = Nummer[:len(Nummer) - 2] + Neu_Index

            if Neu_Nummer in list:
                logger.error('{} ist bereits verwendet. Aktuelle Nummer: {}'.format(Neu_Nummer,Nummer))
            else:
                if Item.LookupParameter('Plannummer'):
                    Item.LookupParameter('Plannummer').Set(Neu_Nummer)
                    list.append(Neu_Nummer)

    t.Commit()


total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))
