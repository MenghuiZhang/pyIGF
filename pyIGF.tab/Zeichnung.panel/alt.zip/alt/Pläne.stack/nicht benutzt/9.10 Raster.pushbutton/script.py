# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

Tstart = time.time()


__title__ = "9.10 Raster(ein Ansichtsfenster)"
__doc__ = """Raster"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc


selection = revit.get_selection()
sel_sheets = forms.select_sheets(title='Select Sheets')

if sel_sheets:
    selection.set_to(sel_sheets)


if not sel_sheets:
    logger.error('Keine Pläne ausgewählt!')
    script.exit()

# Viewports aus aktueller Projekt
Viewports_collector = []

for sheet in sel_sheets:
    views = sheet.GetAllPlacedViews()
    Liste = []
    view_select = None
    viewports = sheet.GetAllViewports()
    for view in views:
        viewtype = doc.GetElement(view).get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString()
        if viewtype == 'Grundriss':
            view_select = doc.GetElement(view)
            break
    Liste.append(view_select)
    for viewport in viewports:
        viewportinstance = doc.GetElement(viewport)
        Liste.append(viewportinstance)

    Viewports_collector.append(Liste)


AnsichtsfensterType = []
for sheet in sel_sheets:
    views = sheet.GetAllViewports()
    for view in views:
        viewtypes = doc.GetElement(view).GetValidTypes()
        for i in viewtypes:
            name = doc.GetElement(i)\
              .get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()
            AnsichtsfensterType.append([name,i])
        break
    break
AnsichtsfensterType.sort()

logger.info("{} Ansichtsfenster ausgewählt".format(len(Viewports_collector)))
if not Viewports_collector:
    logger.error('Keine Ansichtsfenster ausgewählt!')
    script.exit()

t = Transaction(doc, 'Raster ändern')
t.Start()
versatz = None
ansichtstyp = False
if forms.alert('Versatz des Beschriftungszuschneidebereichs auf 10 mm setzen?', ok=False, yes=True, no=True):
    versatz = True

RasterAnpassen = None
if forms.alert('Raster anpassen?', ok=False, yes=True, no=True):
    RasterAnpassen = True

ansichtstyp_aendern = None
if forms.alert('Ansichtsfenster_Typ ändern?', ok=False, yes=True, no=True):
    ops = [i[0] for i in AnsichtsfensterType]
    ansichtstyp_aendern = forms.CommandSwitchWindow.show(ops,message = 'Typen von Ansichtsfenster')

for view in Viewports_collector:
    viewID = view[0].Id
    if versatz:
        cropbox = view[0].GetCropRegionShapeManager()
        cropbox.TopAnnotationCropOffset = 0.032808398950131233
        cropbox.BottomAnnotationCropOffset = 0.032808398950131233
        cropbox.RightAnnotationCropOffset = 0.032808398950131233
        cropbox.LeftAnnotationCropOffset = 0.032808398950131233
    if ansichtstyp_aendern:
        for i in AnsichtsfensterType:
            if ansichtstyp_aendern == i[0]:
                for element in view[1:]:
                    element.ChangeTypeId(i[1])
                break

    if not RasterAnpassen:
        continue
    box = view[0].get_BoundingBox(view[0])
    max_X = box.Max.X
    max_Y = box.Max.Y
    min_X = box.Min.X
    min_Y = box.Min.Y
    rasters_collector = DB.FilteredElementCollector(doc,viewID) \
        .OfCategory(DB.BuiltInCategory.OST_Grids)\
        .WhereElementIsNotElementType()
    rasters = rasters_collector.ToElementIds()
    logger.info("{} Raster in Ansicht {} ausgewählt".format(len(rasters),view[0].Name))
    if not rasters:
        continue

    title = '{value}/{max_value} Raster in Ansicht' + view[0].Name
    with forms.ProgressBar(title=title,cancellable=True, step=2) as pb:
        n_1 = 0
        for raster in rasters_collector:
            if pb.cancelled:
                script.exit()
            n_1 += 1
            pb.update_progress(n_1, len(rasters))
            gridCurves = raster.GetCurvesInView(DB.DatumExtentType.ViewSpecific, view[0] )
            if not gridCurves:
                continue
            for gridCurve in gridCurves:
                start = gridCurve.GetEndPoint( 0 )
                end = gridCurve.GetEndPoint( 1 )
                X1 = start.X
                Y1 = start.Y
                Z1 = start.Z
                X2 = end.X
                Y2 = end.Y
                Z2 = end.Z
                newStart = None
                newEnd = None
                newLine = None
                if abs(X1-X2) > 1:
                    newStart = DB.XYZ(max_X,Y1,Z1)
                    newEnd = DB.XYZ(min_X,Y2,Z2)
                if abs(Y1-Y2) > 1:
                    newStart = DB.XYZ(X1,max_Y,Z1)
                    newEnd = DB.XYZ(X2,min_Y,Z2)
                if all([newStart,newEnd]):
                    newLine = DB.Line.CreateBound( newStart, newEnd )
                if newLine:
                    raster.SetCurveInView(DB.DatumExtentType.ViewSpecific, view[0], newLine )

t.Commit()

total = time.time() - Tstart
logger.info("total time: {} {}".format(total, 100 * "_"))
