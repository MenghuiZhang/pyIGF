# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

Tstart = time.time()


__title__ = "9.50 Raster"
__doc__ = """Raster"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc
active_view = doc.ActiveView

# MEP Räume aus aktueller Projekt
raster_collector = DB.FilteredElementCollector(doc,active_view.Id) \
    .OfCategory(DB.BuiltInCategory.OST_Grids)\
    .WhereElementIsNotElementType()
raster = raster_collector.ToElementIds()

Task = rpw.ui.forms.Alert
Task('Wählen Sie eine Ansicht aus', title="Ansicht", header="Ansicht")

reference = uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, "Ansicht")
ansicht = doc.GetElement(reference)

while(not ansicht):
    logger.error('Keine Ansicht ausgewählt!')
    reference = uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, "Ansicht")

if not ansicht:
    logger.error('Keine Ansicht ausgewählt!')
    script.exit()
# Größe von Ansicht
box = ansicht.get_BoundingBox(active_view)
ansicht_max_X = box.Max.X
ansicht_max_Y = box.Max.Y
ansicht_max_Z = box.Max.Z
ansicht_min_X = box.Min.X
ansicht_min_Y = box.Min.Y
ansicht_min_Z = box.Min.Z

abstand = rpw.ui.forms.TextInput('Versatz von Beschrifungszuschnitt(mm): ', default = "0")
neu_max_X = ansicht_max_X - int(abstand)/6.1
neu_max_Y = ansicht_max_Y - int(abstand)/6.1
neu_max_Z = ansicht_max_Z - int(abstand)/6.1
neu_min_X = ansicht_min_X + int(abstand)/6.1
neu_min_Y = ansicht_min_Y + int(abstand)/6.1
neu_min_Z = ansicht_min_Z + int(abstand)/6.1
if abs(ansicht_max_X - ansicht_min_X) < 1:
    neu_max_X = ansicht_max_X
    neu_min_X = ansicht_min_X
if abs(ansicht_max_X - ansicht_min_X) < 1:
    neu_max_Y = ansicht_max_Y
    neu_min_Y = ansicht_min_Y
if abs(ansicht_max_X - ansicht_min_X) < 1:
    neu_max_Z = ansicht_max_Z
    neu_min_Z = ansicht_min_Z

t = Transaction(doc, 'Raster ändern')
t.Start()
for i in raster_collector:
    gridCurves = i.GetCurvesInView(DB.DatumExtentType.ViewSpecific, active_view )
    if not gridCurves:
        continue
    for gridCurve in gridCurves:
        start = gridCurve.GetEndPoint( 0 )
        end = gridCurve.GetEndPoint( 1 )
        X1 = start.X
        Y1 = start.Y
        Z1 = start.Z
        X2 = end.X
        Y2 = end.Y
        Z2 = end.Z
        newStart = None
        newEnd = None
        newLine = None
        if abs(X1-X2) > 1:
            newStart = DB.XYZ(neu_max_X,Y1,Z1)
            newEnd = DB.XYZ(neu_min_X,Y2,Z2)
        if abs(Y1-Y2) > 1:
            newStart = DB.XYZ(X1,neu_max_Y,Z1)
            newEnd = DB.XYZ(X2,neu_min_Y,Z2)
        if abs(Z1-Z2) > 1:
            newStart = DB.XYZ(X1,Y1,neu_max_Z)
            newEnd = DB.XYZ(X2,Y2,neu_min_Z)
        if all([newStart,newEnd]):
            newLine = DB.Line.CreateBound( newStart, newEnd )
        if newLine:
            i.SetCurveInView(DB.DatumExtentType.ViewSpecific, active_view, newLine )

t.Commit()

total = time.time() - Tstart
logger.info("total time: {} {}".format(total, 100 * "_"))
