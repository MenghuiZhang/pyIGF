# coding: utf8

from pyrevit import revit, UI, DB
from pyrevit import script, forms
import rpw
import time
from Autodesk.Revit.DB import Transaction

Tstart = time.time()


__title__ = "9.50 Raster"
__doc__ = """Raster"""
__author__ = "Menghui Zhang"

logger = script.get_logger()
output = script.get_output()

uidoc = rpw.revit.uidoc
doc = rpw.revit.doc


selection = revit.get_selection()
sel_sheets = forms.select_sheets(title='Select Sheets')

if sel_sheets:
    selection.set_to(sel_sheets)


if not sel_sheets:
    logger.error('Keine Pläne ausgewählt!')
    script.exit()

# Viewports aus aktueller Projekt
Viewports_collector = []

for sheet in sel_sheets:
    views = sheet.GetAllPlacedViews()
    for view in views:
        type = doc.GetElement(view).get_Parameter(DB.BuiltInParameter.ELEM_FAMILY_PARAM).AsValueString()
        if type == 'Grundriss':
            Viewports_collector.append(doc.GetElement(view))

logger.info("{} Ansichtsfenster ausgewählt".format(len(Viewports_collector)))
if not Viewports_collector:
    logger.error('Keine Ansichtsfenster ausgewählt!')
    script.exit()

t = Transaction(doc, 'Raster ändern')
t.Start()
versatz = None
if forms.alert('Versatz des Beschriftungszuschneidebereichs auf 10 mm setzen?', ok=False, yes=True, no=True):
    versatz = True
RasterAnpassen = None
if forms.alert('Raster anpassen?', ok=False, yes=True, no=True):
    RasterAnpassen = True
for view in Viewports_collector:
    viewID = view.Id
    if versatz:
        viewManager = view.GetCropRegionShapeManager()
        cropbox = view.GetCropRegionShapeManager()
        cropbox.TopAnnotationCropOffset = 0.032808398950131233
        cropbox.BottomAnnotationCropOffset = 0.032808398950131233
        cropbox.RightAnnotationCropOffset = 0.032808398950131233
        cropbox.LeftAnnotationCropOffset = 0.032808398950131233
    if not RasterAnpassen:
        continue
    box = view.get_BoundingBox(view)
    max_X = box.Max.X
    max_Y = box.Max.Y
    min_X = box.Min.X
    min_Y = box.Min.Y
    rasters_collector = DB.FilteredElementCollector(doc,viewID) \
        .OfCategory(DB.BuiltInCategory.OST_Grids)\
        .WhereElementIsNotElementType()
    rasters = rasters_collector.ToElementIds()
    logger.info("{} Raster in Ansicht {} ausgewählt".format(len(rasters),view.Name))
    if not rasters:
        continue

    title = '{value}/{max_value} Raster in Ansicht' + view.Name
    with forms.ProgressBar(title=title,cancellable=True, step=2) as pb:
        n_1 = 0
        for raster in rasters_collector:
            if pb.cancelled:
                script.exit()
            n_1 += 1
            pb.update_progress(n_1, len(rasters))
            gridCurves = raster.GetCurvesInView(DB.DatumExtentType.ViewSpecific, view )
            if not gridCurves:
                continue
            for gridCurve in gridCurves:
                start = gridCurve.GetEndPoint( 0 )
                end = gridCurve.GetEndPoint( 1 )
                X1 = start.X
                Y1 = start.Y
                Z1 = start.Z
                X2 = end.X
                Y2 = end.Y
                Z2 = end.Z
                newStart = None
                newEnd = None
                newLine = None
                if abs(X1-X2) > 1:
                    newStart = DB.XYZ(max_X,Y1,Z1)
                    newEnd = DB.XYZ(min_X,Y2,Z2)
                if abs(Y1-Y2) > 1:
                    newStart = DB.XYZ(X1,max_Y,Z1)
                    newEnd = DB.XYZ(X2,min_Y,Z2)
                if all([newStart,newEnd]):
                    newLine = DB.Line.CreateBound( newStart, newEnd )
                if newLine:
                    raster.SetCurveInView(DB.DatumExtentType.ViewSpecific, view, newLine )

t.Commit()

total = time.time() - Tstart
logger.info("total time: {} {}".format(total, 100 * "_"))
