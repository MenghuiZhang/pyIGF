# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from rpw import revit,DB
from pyrevit import script, forms
from IGF_log import getlog
from IGF_lib import get_value
import time

start = time.time()


__title__ = "3.3 Raumluft_Schacht"
__doc__ = """Schachtberechnung

[30.09.2021]
Version: 1.1"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc
# MEP Räume aus aktueller Projekt
spaces_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType()
spaces = spaces_collector.ToElementIds()

logger.info("{} MEP Räume ausgewählt".format(len(spaces)))

if not spaces:
    logger.error("Keine MEP Räume in aktueller Projekt gefunden")
    script.exit()


class MEPRaum:
    def __init__(self, element_id):
        self.element_id = element_id
        self.element = doc.GetElement(self.element_id)
        self.ZuSchacht = 0
        self.AbSchacht = 0
        self.Ab24hSchacht = 0
        attr = [
            ['name', 'Name'],
            ['nummer', 'Nummer'],
            ['Install_Schacht', 'TGA_RLT_InstallationsSchacht'],
            ['Install_Schacht_Name', 'TGA_RLT_InstallationsSchachtName'],
            ['Zu_Schacht_Nr', 'TGA_RLT_SchachtZuluft'],
            ['Zul', 'IGF_RLT_AnlagenRaumZuluft'],
            ['Ab_Schacht_Nr', 'TGA_RLT_SchachtAbluft'],
            ['Abl', 'IGF_RLT_AnlagenRaumAbluft'],
            ['Ab_24h_Schacht_Nr', 'TGA_RLT_Schacht24hAbluft'],
            ['Abl_24h', 'IGF_RLT_AnlagenRaum24hAbluft'],
        ]

        for a in attr:
            python_name, revit_name = a
            setattr(self, python_name, self.get_element_attr(revit_name))
        
    @property
    def ZuSchacht(self):
        return self._ZuSchacht
    @ZuSchacht.setter
    def ZuSchacht(self,value):
        self._ZuSchacht = value
    @property
    def AbSchacht(self):
        return self._AbSchacht
    @AbSchacht.setter
    def AbSchacht(self,value):
        self._AbSchacht = value
    @property
    def Ab24hSchacht(self):
        return self._Ab24hSchacht
    @Ab24hSchacht.setter
    def Ab24hSchacht(self,value):
        self._Ab24hSchacht = value

    def get_element_attr(self, param_name):
        param = self.element.LookupParameter(param_name)

        if not param:
            logger.error(
                "Parameter {} konnte nicht gefunden werden".format(param_name))
            return

        return get_value(param)
    
    def werte_schreiben(self):
        """Schreibt die berechneten Werte zurück in das Modell."""
        def wert_schreiben(param_name, wert):
            if not wert is None:
                param = self.element.LookupParameter(param_name)
                if param:
                    if param.StorageType.ToString() == 'Double':
                        param.SetValueString(str(wert))
                    else:
                        param.Set(wert)

        wert_schreiben("TGA_RLT_SchachtZuluftMenge", self.ZuSchacht)
        wert_schreiben("TGA_RLT_SchachtAbluftMenge", self.AbSchacht)
        wert_schreiben("TGA_RLT_Schacht24hAbluftMenge", self.Ab24hSchacht)


    def table_row_Raum(self):
        return [self.nummer, self.name, self.Zu_Schacht_Nr, self.Zul, self.Ab_Schacht_Nr,
                self.Abl, self.Ab_24h_Schacht_Nr, self.Abl_24h]
    
    def table_row_Scahcht(self):
        return [self.Install_Schacht_Name, self.ZuSchacht, self.AbSchacht, self.Ab24hSchacht]


Raum_liste = []
Schacht_liste = []
table_data_Raum = []
table_data_Schacht = []
Schacht_Daten = {}

with forms.ProgressBar(title='{value}/{max_value} MEP-Räume',cancellable=True, step=10) as pb:
    for n, space_id in enumerate(spaces):
        if pb.cancelled:
            script.exit()

        pb.update_progress(n + 1, len(spaces))
        mepraum = MEPRaum(space_id)

        Raum_liste.append(mepraum)
        if mepraum.Zu_Schacht_Nr in Schacht_Daten.keys():
            Schacht_Daten[mepraum.Zu_Schacht_Nr][0] += float(mepraum.Zul)
        else:
            Schacht_Daten[mepraum.Zu_Schacht_Nr] = [float(mepraum.Zul),0.0,0.0]
        if mepraum.Ab_Schacht_Nr in Schacht_Daten.keys():
            Schacht_Daten[mepraum.Ab_Schacht_Nr][1] += float(mepraum.Abl)
        else:
            Schacht_Daten[mepraum.Ab_Schacht_Nr] = [0.0,float(mepraum.Abl),0.0]
        if mepraum.Ab_24h_Schacht_Nr in Schacht_Daten.keys():
            Schacht_Daten[mepraum.Ab_24h_Schacht_Nr][2] += float(mepraum.Abl_24h)
        else:
            Schacht_Daten[mepraum.Ab_24h_Schacht_Nr]= [0.0,0.0,float(mepraum.Abl_24h)]
        table_data_Raum.append(mepraum.table_row_Raum())
        
        if mepraum.Install_Schacht:
            Schacht_liste.append(mepraum)

#Sortieren nach Raumnummer
table_data_Raum.sort()

output.print_table(
    table_data = table_data_Raum,
    title="MEP-Räume",
    columns=['Zu_Schacht_Nr','Zuluft', 'Ab_Schacht_Nr', 'Abluft', '24h_Schacht_Nr', '24h-Abluft']
)

with forms.ProgressBar(title='{value}/{max_value} Schächte',cancellable=True, step=1) as pb1:
    for n, schacht in enumerate(Schacht_liste):
        if pb1.cancelled:
            script.exit()

        pb1.update_progress(n + 1, len(Schacht_liste))

        if schacht.Install_Schacht_Name in Schacht_Daten.keys():
            schacht.ZuSchacht = Schacht_Daten[schacht.Install_Schacht_Name][0]
            schacht.AbSchacht = Schacht_Daten[schacht.Install_Schacht_Name][1]
            schacht.Ab24hSchacht = Schacht_Daten[schacht.Install_Schacht_Name][2]
            table_data_Schacht.append(schacht.table_row_Scahcht())

table_data_Schacht.sort()

output.print_table(
    table_data = table_data_Schacht,
    title="Schächte",
    columns=['Install_Schacht_Name', 'Zuluft', 'Abluft', '24h-Abluft']
)

# Werte zuückschreiben + Abfrage
if forms.alert('Berechnete Werte in Modell schreiben?', ok=False, yes=True, no=True):
    with forms.ProgressBar(title='{value}/{max_value} Werte schreiben',cancellable=True, step=1) as pb2:

        t = DB.Transaction(doc, "Luftmengen Schächte")
        t.Start()

        for n, schacht in enumerate(Schacht_liste):
            if pb2.cancelled:
                t.RollBack()
                script.exit()

            pb2.update_progress(n + 1, len(Schacht_liste))
            schacht.werte_schreiben()
        t.Commit()

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))