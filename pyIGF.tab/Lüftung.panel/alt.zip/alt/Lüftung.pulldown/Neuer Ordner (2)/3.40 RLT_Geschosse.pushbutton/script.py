# coding: utf8
import sys
sys.path.append(r'R:\pyRevit\xx_Skripte\libs\IGF_libs')
from rpw import revit,DB
from pyrevit import script, forms
from IGF_log import getlog
from IGF_lib import get_value
import time

start = time.time()


__title__ = "3.4 Raumluft_Verteilung"
__doc__ = """Luft Verteilung

[30.09.2021]
Version: 1.1"""
__author__ = "Menghui Zhang"

try:
    getlog(__title__)
except:
    pass

logger = script.get_logger()
output = script.get_output()

uidoc = revit.uidoc
doc = revit.doc


# MEP Räume aus aktueller Projekt
spaces_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType()
spaces = spaces_collector.ToElementIds()

logger.info("{} MEP Räume ausgewählt".format(len(spaces)))

if not spaces:
    logger.error("Keine MEP Räume in aktueller Projekt gefunden")
    script.exit()

class MEPRaum:
    def __init__(self, element_id):
        self.element_id = element_id
        self.element = doc.GetElement(self.element_id)
        self.ZuSchacht = ''
        self.AbSchacht = ''
        self.Ab24hSchacht = ''
        attr = [
            ['name', 'Name'],
            ['nummer', 'Nummer'],
            ['ebene', 'IGF_RLT_Verteilung_EbenenName'],
            ['ebene_nr', 'IGF_RLT_Verteilung_EbenenSortieren'],
            # Anlagen
            ['Zu_Anl_Nr', 'TGA_RLT_AnlagenNrZuluft'],
            ['Ab_Anl_Nr', 'TGA_RLT_AnlagenNrAbluft'],
            ['Ab_Anl_Nr_24h', 'TGA_RLT_AnlagenNr24hAbluft'],

            ['Install_Schacht', 'TGA_RLT_InstallationsSchacht'],
            ['Install_Schacht_Name', 'TGA_RLT_InstallationsSchachtName'],

            # Luftmengen
            ['ZU', 'IGF_RLT_AnlagenRaumZuluft'],
            ['AB', 'IGF_RLT_AnlagenRaumAbluft'],
            ['AB24H', 'IGF_RLT_AnlagenRaum24hAbluft'],
            # Schacht
            ['ZU_S', 'TGA_RLT_SchachtZuluft'],
            ['AB_S', 'TGA_RLT_SchachtAbluft'],
            ['AB24H_S', 'TGA_RLT_Schacht24hAbluft']
        ]

        for a in attr:
            python_name, revit_name = a
            setattr(self, python_name, self.get_element_attr(revit_name))

        # Prüfung
        if self.ZU > 0:
            if not (self.Zu_Anl_Nr and self.ZU_S):
                logger.error("Zuluft-Anlage-Nummer/Zuluft-Schacht in Raum {} nicht gefunden".format(self.nummer))

        if self.AB > 0:
            if not (self.Ab_Anl_Nr and self.AB_S):
                logger.error("Abluft-Anlage-Nummer/Abluft-Schacht in Raum {} nicht gefunden".format(self.nummer))

        if self.AB24H > 0:
            if not (self.Ab_Anl_Nr_24h and self.AB24H_S):
                logger.error("24h-Abluft-Anlage-Nummer/24h-Abluft-Schacht in Raum {} nicht gefunden".format(self.nummer))

        
    @property
    def ZuSchacht(self):
        return self._ZuSchacht
    @ZuSchacht.setter
    def ZuSchacht(self,value):
        self._ZuSchacht = value
    @property
    def AbSchacht(self):
        return self._AbSchacht
    @AbSchacht.setter
    def AbSchacht(self,value):
        self._AbSchacht = value
    @property
    def Ab24hSchacht(self):
        return self._Ab24hSchacht
    @Ab24hSchacht.setter
    def Ab24hSchacht(self,value):
        self._Ab24hSchacht = value

    def get_element_attr(self, param_name):
        param = self.element.LookupParameter(param_name)

        if not param:
            logger.error(
                "Parameter {} konnte nicht gefunden werden".format(param_name))
            return

        return get_value(param)
    
    def table_row_Scahcht(self):
        return [self.Install_Schacht_Name,self.nummer,self.name, self.ZuSchacht, self.AbSchacht, self.Ab24hSchacht]
    
    def werte_schreiben(self):
        """Schreibt die berechneten Werte zurück in das Modell."""
        def wert_schreiben(param_name, wert):
            if not wert is None:
                param = self.element.LookupParameter(param_name)
                if param:
                    if param.StorageType.ToString() == 'Double':
                        param.SetValueString(str(wert))
                    else:
                        param.Set(wert)

        wert_schreiben("IGF_RLT_VerteilungZuluft", self.ZuSchacht)
        wert_schreiben("IGF_RLT_VerteilungAbluft", self.AbSchacht)
        wert_schreiben("IGF_RLT_Verteilung24hAbluft", self.Ab24hSchacht)


Schacht_liste = []
table_data_Schacht = []
Schacht_Daten = {}
Ebene_nr_name = {}

with forms.ProgressBar(title='{value}/{max_value} MEP Räume',cancellable=True, step=10) as pb:
    for n, space_id in enumerate(spaces):
        if pb.cancelled:
            script.exit()
        pb.update_progress(n + 1, len(spaces))
        mepraum = MEPRaum(space_id)

        if not mepraum.ebene_nr in Ebene_nr_name.keys():
            Ebene_nr_name[mepraum.ebene_nr] = mepraum.ebene

        if float(mepraum.ZU) > 1:
            if not mepraum.ZU_S in Schacht_Daten.keys():
                Schacht_Daten[mepraum.ZU_S] = {'0':{},'1':{},'2':{}}
            if not mepraum.ebene_nr in Schacht_Daten[mepraum.ZU_S]['0'].keys():
                Schacht_Daten[mepraum.ZU_S]['0'][mepraum.ebene_nr] = {}
            if not mepraum.Zu_Anl_Nr in Schacht_Daten[mepraum.ZU_S]['0'][mepraum.ebene_nr].keys():
                Schacht_Daten[mepraum.ZU_S]['0'][mepraum.ebene_nr][mepraum.Zu_Anl_Nr] = float(mepraum.ZU)
            else:
                Schacht_Daten[mepraum.ZU_S]['0'][mepraum.ebene_nr][mepraum.Zu_Anl_Nr] += float(mepraum.ZU)

        if float(mepraum.AB) > 1:
            if not mepraum.AB_S in Schacht_Daten.keys():
                Schacht_Daten[mepraum.AB_S] = {'0':{},'1':{},'2':{}}
            if not mepraum.ebene_nr in Schacht_Daten[mepraum.AB_S]['1'].keys():
                Schacht_Daten[mepraum.AB_S]['1'][mepraum.ebene_nr] = {}
            if not mepraum.Ab_Anl_Nr in Schacht_Daten[mepraum.AB_S]['1'][mepraum.ebene_nr].keys():
                Schacht_Daten[mepraum.AB_S]['1'][mepraum.ebene_nr][mepraum.Ab_Anl_Nr] = float(mepraum.AB)
            else:
                Schacht_Daten[mepraum.AB_S]['1'][mepraum.ebene_nr][mepraum.Ab_Anl_Nr] += float(mepraum.AB)


        if float(mepraum.AB24H) > 1:
            if not mepraum.AB24H_S in Schacht_Daten.keys():
                
                Schacht_Daten[mepraum.AB24H_S] = {'0':{},'1':{},'2':{}}
            if not mepraum.ebene_nr in Schacht_Daten[mepraum.AB24H_S]['2'].keys():
                Schacht_Daten[mepraum.AB24H_S]['2'][mepraum.ebene_nr] = {}
            if not mepraum.Ab_Anl_Nr_24h in Schacht_Daten[mepraum.AB24H_S]['2'][mepraum.ebene_nr].keys():
                Schacht_Daten[mepraum.AB24H_S]['2'][mepraum.ebene_nr][mepraum.Ab_Anl_Nr_24h] = float(mepraum.AB24H)
            else:
                Schacht_Daten[mepraum.AB24H_S]['2'][mepraum.ebene_nr][mepraum.Ab_Anl_Nr_24h] += float(mepraum.AB24H)

        if mepraum.Install_Schacht:
            Schacht_liste.append(mepraum)

with forms.ProgressBar(title='{value}/{max_value} Schächte',cancellable=True, step=1) as pb1:
    for n, schacht in enumerate(Schacht_liste):
        if pb1.cancelled:
            script.exit()
        pb1.update_progress(n + 1, len(Schacht_liste))

        Schacht_zu = ''
        Schacht_ab = ''
        Schacht_ab24h = ''

        if schacht.Install_Schacht_Name in Schacht_Daten.keys():
            Zu_Dict = Schacht_Daten[schacht.Install_Schacht_Name]['0']
            Ab_Dict = Schacht_Daten[schacht.Install_Schacht_Name]['1']
            Ab24h_Dict = Schacht_Daten[schacht.Install_Schacht_Name]['2']
            sorted(Zu_Dict)
            sorted(Ab_Dict)
            sorted(Ab24h_Dict)
            for eb in Zu_Dict.keys():
                Schacht_zu += str(Ebene_nr_name[eb]) + ': '
                Zu_Dict_eb = Zu_Dict[eb]
                zu_keys = Zu_Dict_eb.keys()[:]
                zu_keys.sort()
                for anl in zu_keys:
                    Schacht_zu += 'Anl ' + str(anl) + '=' + str(int(round(Zu_Dict_eb[anl]))) + ', '
            if Schacht_zu:
                schacht.ZuSchacht = '[m3/h] - ' + Schacht_zu[:-2]
            
            
            for eb in Ab_Dict.keys():
                Schacht_ab += str(Ebene_nr_name[eb]) + ': '
                Ab_Dict_eb = Ab_Dict[eb]
                ab_keys = Ab_Dict_eb.keys()[:]
                ab_keys.sort()
                for anl in ab_keys:
                    Schacht_ab += 'Anl ' + str(anl) + '=' + str(int(round(Ab_Dict_eb[anl]))) + ', '
            if Schacht_ab:
                schacht.AbSchacht = '[m3/h] - ' + Schacht_ab[:-2]
            
            for eb in Ab24h_Dict.keys():
                Schacht_ab24h += str(Ebene_nr_name[eb]) + ': '
                Ab24h_Dict_eb = Ab24h_Dict[eb]
                ab24h_keys = Ab24h_Dict_eb.keys()[:]
                ab24h_keys.sort()
                for anl in ab24h_keys:
                    Schacht_ab24h += 'Anl ' + str(anl) + '=' + str(int(round(Ab24h_Dict_eb[anl]))) + ', '
            if Schacht_ab24h:
                schacht.Ab24hSchacht = '[m3/h] - ' + Schacht_ab24h[:-2]
        
        table_data_Schacht.append(schacht.table_row_Scahcht())
table_data_Schacht.sort()

output.print_table(
    table_data=table_data_Schacht,
    title="Luftmengen Verteilung",
    columns=['Schachtname','Nummer', 'Name', 'Zuluft','Abluft', 'Abluft_24h']
)
print(table_data_Schacht)
# Werte zuückschreiben + Abfrage
if forms.alert('Berechnete Werte in Modell schreiben?', ok=False, yes=True, no=True):
    with forms.ProgressBar(title='{value}/{max_value} Werte schreiben',cancellable=True, step=1) as pb2:

        t = DB.Transaction(doc, "Luftmengen Verteilung")
        t.Start()

        for n, schacht in enumerate(Schacht_liste):
            if pb2.cancelled:
                t.RollBack()
                script.exit()

            pb2.update_progress(n + 1, len(Schacht_liste))
            schacht.werte_schreiben()
        t.Commit()

total = time.time() - start
logger.info("total time: {} {}".format(total, 100 * "_"))